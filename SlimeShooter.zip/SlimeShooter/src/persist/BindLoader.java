package persist;

import utilsbinding.DataToSave;

import java.beans.XMLDecoder;
import java.io.BufferedInputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;

/**
 * Classe utilisée pour charger les controles du jeu depuis un fichier XML
 */
public class BindLoader {

    private String filename;

    public BindLoader(String file){
        this.filename = file;
    }

    public DataToSave chargerBinds() throws FileNotFoundException {

       XMLDecoder decoder = new XMLDecoder(new BufferedInputStream(new FileInputStream(this.filename)));

       DataToSave data = (DataToSave) decoder.readObject();
        return data;

    }

}



