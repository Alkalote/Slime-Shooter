package persist;


import utilsbinding.DataToSave;

import java.beans.XMLEncoder;
import java.io.BufferedOutputStream;
import java.io.FileOutputStream;
import java.io.IOException;


/**
 * Classe utilisée pour sauver les controles en jeu dans un fichier XML
 */
public class BindSaver {

    private String filename;

    public BindSaver(String file){
        this.filename = file;
    }

    public void saveBinds(DataToSave data) throws IOException {


        FileOutputStream writer = new FileOutputStream(this.filename);
        writer.write(("").getBytes());
        writer.close();

        try (XMLEncoder encoder = new XMLEncoder(new BufferedOutputStream(
                new FileOutputStream(this.filename)))) {


            encoder.writeObject(data);
            encoder.flush();
        } catch (final IOException e) {
            e.printStackTrace();
        }
    }



}
