package persist;


import utilsbinding.Bo5scores;

import java.beans.XMLDecoder;
import java.io.BufferedInputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;

/**
 * Classe permettant de charger une liste de scores depuis un fichier XML
 */
public class ScoreLoader {

    private String filename;

    public ScoreLoader(String file){
        this.filename = file;
    }

    public Bo5scores loadScores() throws FileNotFoundException {

        XMLDecoder decoder;

        decoder = new XMLDecoder(new BufferedInputStream(new FileInputStream(this.filename)));
        final Bo5scores scoreList = (Bo5scores) decoder.readObject();

        decoder.close();
        return scoreList;

    }

}
