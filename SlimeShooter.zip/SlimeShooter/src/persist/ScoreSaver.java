package persist;



import utilsbinding.Bo5scores;

import java.beans.XMLEncoder;
import java.io.BufferedOutputStream;
import java.io.FileOutputStream;

/**
 * Classe qui permet de sauvegarder des scores dans un fichier XML
 */

public class ScoreSaver {

    private String filename;

    public ScoreSaver(String file){
        this.filename = file;
    }

    public void saveScores(Bo5scores scoreList){

        try (XMLEncoder encoder = new XMLEncoder(new BufferedOutputStream(
                new FileOutputStream(this.filename)))) {

            encoder.writeObject(scoreList);
            encoder.flush();
        } catch (final java.io.IOException e) {
            e.printStackTrace();
        }

    }

}
