package sprite.bullets;

import collisions.HitBox;
import collisions.managers.CollisionManager;
import displacer.Displacer;
import javafx.scene.paint.Color;
import utils.SimpleVector;
import sprite.MovingSprite;

/**
 * Balle dans le jeu, fait des dégâts aux monstres
 */
public class Bullet extends MovingSprite {
    private final SimpleVector directionProj;
    public Bullet(int posX, int posY, int objectiveX, int objectiveY, int atk, CollisionManager collisionManager,
                  Displacer displacer) {
        super(collisionManager, new HitBox(posX, posY, 10, 10), "/skins/bouleDeFeu.png",
                Color.BLACK, 1, 1, atk, 25, displacer);
        directionProj = new SimpleVector(posX, posY, objectiveX, objectiveY);
    }

    @Override
    public void move() {
        displacer.move(this, directionProj);
    }

    @Override
    public void moveReverse(int objectiveX, int objectiveY) {

    }

    @Override
    public boolean canMove() {
        return displacer.canMove(this, directionProj);
    }

    @Override
    public boolean canMoveReverse(int objectiveX, int objectiveY) {
        return false;
    }

    public SimpleVector getDirectionProj() {
        return directionProj;
    }
}
