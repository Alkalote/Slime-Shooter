package sprite.monster;

import collisions.HitBox;
import collisions.managers.CollisionManager;
import displacer.Displacer;
import javafx.scene.paint.Color;
import sprite.MovingSprite;
import sprite.Sprite;
import utils.SimpleVector;

/**
 * MonsterSprite permet de rajouter des monstres au jeu.
 * Un monstre suis par défaut son objectif qui est souvent le joueur.
 * Un monstre est capable de se déplacer car il hérite de MovingSprite.
 * Cette classe définit le strict minimum pour qu'un monstre soit rajouté dans le jeu
 * Pour rajouter un monstre dans le jeu, vous devez OBLIGATOIREMENT suivre les étapes suivantes:
 *   - Faire une nouvelle classe nommée en CamleCase qui hérite de MonsterSprite dans sprite.monster.concret
 *   - L'ajouter dans l'enum MobType en suivant les indications de sa documentation
 * [FACULTATIF]
 *   - Faire une classe qui hérite de Displacer pour définir vous même l'algorithme de déplacement du monstre
 *   - Faire une classe qui hérite de CollisionManager pour définir vous même l'algorithme de gestion des collisions
 *     appliqué a votre monstre
 * @see MovingSprite
 * @see MobType
 * @see sprite.monster.concret.BasicMonsterSprite
 * @see sprite.monster.concret.StrongMonsterSprite
 * @see Displacer
 * @see CollisionManager
 */
public abstract class MonsterSprite extends MovingSprite {
    private int baseDamageCoolDown;
    private int activeDamageCoolDown;
    private int scoreValue;
    private int moneyReward;
    private Sprite objective;

    /**
     * Constructeur de MonsterSprite, il est conseillé d'utiliser super() pour les classes qui vont hériter de lui
     * afin de ne pas oublier de renseigner une variable de MonsterSprite.
     * Oublier de renseigner une variable mènera a un comportement indéterminé voir une Exception
     * @param collisionManager
     * @param displacer
     * @param hitBox
     * @param skin
     * @param color
     * @param pv
     * @param maxPv
     * @param atk
     * @param speed
     * @param objective
     * @param baseDamageCoolDown
     * @param scoreValue
     * @param moneyReward
     */
    protected MonsterSprite(CollisionManager collisionManager, Displacer displacer, HitBox hitBox, String skin,
                            Color color, int pv, int maxPv, int atk, int speed, Sprite objective, int baseDamageCoolDown,
                            int scoreValue, int moneyReward) {
        super(collisionManager, hitBox, skin, color, pv, maxPv, atk, speed, displacer);
        this.baseDamageCoolDown = baseDamageCoolDown;
        this.scoreValue = scoreValue;
        this.moneyReward = moneyReward;
        this.objective = objective;
        activeDamageCoolDown = 0;
        enableLifeBar = true;
    }

    /**
     * Dit si le monstre peut attaquer en fonction de son cooldown restant
     * @return
     */
    public boolean canAttack() {
        return activeDamageCoolDown == 0;
    }

    /**
     * Décrémente le cooldown d'attaque si le monstre est en cooldown d'attaque
     */
    public void reduceCooldown(){
        if (activeDamageCoolDown != 0){
            activeDamageCoolDown = activeDamageCoolDown -1;
        }
    }

    /**
     * Démarre un cooldown d'attaque, durant ce laps de temps, le monstre ne sera plus en mesure d'infliger des
     * dégats
     */
    public void startCooldown(){
        activeDamageCoolDown = baseDamageCoolDown;
    }

    /**
     * Le monstre suis son objectif
     */
    @Override
    public void move(){
        if (!canMove()) return;
        displacer.move(this,
                new SimpleVector(this.getCenterX(), this.getCenterY(), objective.getCenterX(), objective.getCenterY()));
    }

    /**
     * Le monstre se déplace dans la direction opposée de l'objectif donné en paramètre
     * @param objectiveX
     * @param objectiveY
     */
    @Override
    public void moveReverse(int objectiveX, int objectiveY){
        //if (!canMoveReverse(objectiveX, objectiveY)) return;
        displacer.move(this,
                new SimpleVector(objectiveX, objectiveY, getCenterX(), getCenterY()));
    }

    /**
     * Dit si le monstre peut bouger ou non
     * @return
     */
    @Override
    public boolean canMove(){
        return displacer.canMove(this,
                new SimpleVector(this.getCenterX(), this.getCenterY(), objective.getCenterX(), objective.getCenterY()));
    }

    /**
     * Dit si le monstre peut bouger dans la direction opposée par rapport a l'objectif donné en paramètre
     * @param objectiveX
     * @param objectiveY
     * @return
     */
    @Override
    public boolean canMoveReverse(int objectiveX, int objectiveY){
        return displacer.canMove(this,
                new SimpleVector(objectiveX, objectiveY, getCenterX(), getCenterY()));
    }

    public int getScoreValue() {
        return scoreValue;
    }

    public int getMoneyReward(){
        return moneyReward;
    }
}
