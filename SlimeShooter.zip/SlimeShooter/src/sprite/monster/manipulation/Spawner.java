package sprite.monster.manipulation;

import collisions.managers.CollisionManager;
import collisions.managers.MonsterCollisionManager;
import displacer.MonsterDisplacer;
import displacer.Displacer;
import sprite.Sprite;
import sprite.monster.MonsterSprite;
import utils.GameScreen;
import world.World;

import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.util.Random;

/**
 * S'occupe de faire apparaitre des monstres
 */
public class Spawner {
    private final GameScreen gameScreen;
    private final Random random;
    private final MonsterDisplacer monsterDisplacer;
    private final MonsterCollisionManager monsterCollisionManager;

    /**
     * Constructeur de Spawner
     * @param gameScreen
     */
    public Spawner(GameScreen gameScreen) {
        this.gameScreen = gameScreen;
        random = new Random();
        monsterCollisionManager = new MonsterCollisionManager();
        monsterDisplacer = new MonsterDisplacer(gameScreen);
    }

    /**
     * Fait appaitre un monstre en utilisant de l'introspection, attention a bien suivre les étapes d'ajout de nouveau
     * monstre pour ne pas générer d'exception ici.
     * @param mobClassName
     * @param world
     * @param objective
     * @throws ClassNotFoundException
     * @throws InstantiationException
     * @throws IllegalAccessException
     * @throws NoSuchMethodException
     * @throws InvocationTargetException
     * @see MonsterSprite
     */
    public void spawnMob(String mobClassName, World world, Sprite objective) throws ClassNotFoundException,
            InstantiationException, IllegalAccessException, NoSuchMethodException, InvocationTargetException {
        Class<?> mobClass = Class.forName(mobClassName);
        Constructor<?> mobConstruct = mobClass.getConstructor(CollisionManager.class,
                Displacer.class, int.class, int.class, Sprite.class);
        int randX = 0;
        while (randX < 50){
            randX = random.nextInt(gameScreen.getxMax()-50);
        }
        int randY = 0;
        while (randY < 50){
            randY = random.nextInt(gameScreen.getyMax()/2);
        }
        MonsterSprite spawn = (MonsterSprite) mobConstruct.newInstance(monsterCollisionManager, monsterDisplacer,
                randX, randY, objective);
        world.getSpritesOnWorld().add(spawn);
    }
}
