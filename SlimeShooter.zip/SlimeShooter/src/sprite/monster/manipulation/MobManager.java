package sprite.monster.manipulation;

import sprite.Sprite;
import utils.GameScreen;
import world.World;

import java.lang.reflect.InvocationTargetException;

/**
 * Gestionnaire de monstre
 */
public class MobManager {
    private final Spawner spawner;

    public MobManager(GameScreen gameScreen){
        spawner = new Spawner(gameScreen);
    }

    /**
     * Fait apparaitre un monstre
     * @param mobClassName
     * @param world
     * @param objective
     */
    public void spawnMob(String mobClassName, World world, Sprite objective){
        try {
            spawner.spawnMob(mobClassName, world, objective);
        }
        catch (ClassNotFoundException | InstantiationException | IllegalAccessException
        | InvocationTargetException | NoSuchMethodException e){
            e.printStackTrace();
        }
    }

}
