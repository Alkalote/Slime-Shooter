package sprite.monster.concret;

import collisions.HitBox;
import collisions.managers.CollisionManager;
import displacer.Displacer;
import javafx.scene.paint.Color;
import sprite.Sprite;
import sprite.monster.MonsterSprite;

/**
 * Monstre de base du jeu
 */
public class BasicMonsterSprite extends MonsterSprite {
    private static int nextPv = 1;
    private static int nextMoney = 1;
    public BasicMonsterSprite(CollisionManager collisionManager, Displacer displacer, int posX, int posY, Sprite objective){
        super(collisionManager, displacer, new HitBox(posX, posY, 50, 50), "/skins/basicMob.png",
                Color.RED, nextPv, nextPv, 1, 4, objective, 10, 10, nextMoney);
    }

    /**
     * Fait évoluer le monstre
     */
    public static void evoluteMobType(){
        nextPv = nextPv*2;
        nextMoney = nextMoney*2;
    }
}
