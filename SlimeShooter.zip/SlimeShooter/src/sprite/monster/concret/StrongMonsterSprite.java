package sprite.monster.concret;

import collisions.HitBox;
import collisions.managers.CollisionManager;
import displacer.Displacer;
import javafx.scene.paint.Color;
import sprite.Sprite;
import sprite.monster.MonsterSprite;
import utils.SimpleVector;

/**
 * Monstre un peu plus fort que celui de base
 */
public class StrongMonsterSprite extends MonsterSprite {
    private static int nextPv = 15;
    private static int nextMoney = 8;
    public StrongMonsterSprite(CollisionManager collisionManager, Displacer displacer, int posX, int posY, Sprite objective){
        super(collisionManager, displacer, new HitBox(posX, posY, 70, 70), "/skins/strongMob.png",
                Color.RED, nextPv,nextPv, 1, 2, objective, 10, 50, nextMoney);
    }
    public static void evoluteMobType(){
        nextPv = nextPv*3;
        nextMoney = nextMoney*2;
    }
}
