package sprite.monster.concret;

import collisions.HitBox;
import collisions.managers.CollisionManager;
import displacer.Displacer;
import javafx.scene.paint.Color;
import sprite.Sprite;
import sprite.monster.MonsterSprite;
import utils.SimpleVector;

/**
 * MiniBoss, pimente un peu la difficulté
 */
public class MiniBossMonsterSprite extends MonsterSprite {
    private static int nextPv = 100;
    private static int nextMoney = 100;
    public MiniBossMonsterSprite(CollisionManager collisionManager, Displacer displacer, int posX, int posY, Sprite objective){
        super(collisionManager, displacer, new HitBox(posX, posY, 100, 100),
                "/skins/bossSlime.png", Color.RED, nextPv, nextPv, 15, 2, objective,
                20, 200, nextMoney);
        nextPv = nextPv*2;
    }
    public static void evoluteMobType(){
        nextMoney = nextMoney*2;
    }

    /**
     * Empêche le boss d'être poussé par les autres monstres
     * @param objectiveX
     * @param objectiveY
     */
    @Override
    public void moveReverse(int objectiveX, int objectiveY){}
}
