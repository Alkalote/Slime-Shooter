package sprite.monster;

/**
 * Enumère tout les monstres présents dans le jeu:
 * Pour rajouter un monstre dans le jeu vous DEVEZ respecter la convention suivante:
 * - Le nom de votre classe qui extend MonsterSprite doit être en CamelCase.
 * - Vous devez inscrire votre nouvelle classe dans cet enum en écrivant les mots en majuscule et en les séparant par
 *   des "_".
 *   Exemple:
 *     BasicMonsterSprite -> BASIC_MONSTER_SPRITE
 *     StrongMonsterSprite -> STRONG_MONSTER_SPRITE
 * @see MonsterSprite
 * @see sprite.monster.concret.BasicMonsterSprite
 * @see sprite.monster.concret.StrongMonsterSprite
 */
public enum MobType {
    BASIC_MONSTER_SPRITE,
    STRONG_MONSTER_SPRITE,
    MINI_BOSS_MONSTER_SPRITE
}
