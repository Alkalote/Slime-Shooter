package sprite;

import collisions.HitBox;
import collisions.managers.CollisionManager;
import javafx.scene.image.Image;
import javafx.scene.paint.Color;

import java.io.InputStream;

/**
 * Sprite est la classe qui régit les règles de toute entitée présente a l'écran,
 * Les collisons d'un sprite sont gérées par l'intermédiaire d'un CollisionManager, vous pouvez choisir l'algorithme
 * de collision utilisé en spécifiant un CollisionManager.
 * @see CollisionManager
 */
public abstract class Sprite {
    private final CollisionManager collisionManager;
    private final HitBox hitBox;
    private final Color color;
    private final int maxPv;
    private final Image image;
    private int pv;
    private int atk;
    protected boolean enableLifeBar = false;

    /**
     * Constructeur de Sprite, il est conseillé d'utiliser super() lorque vous faites dériver une classe de Sprite
     * afin de ne pas oublier de renseigner une variable. Si une variable n'est pas renseignée alors le comportement de
     * la classe sera indéterminée voir génèrera une Exception.
     * @param collisionManager
     * @param hitBox
     * @param skin
     * @param color
     * @param pv
     * @param maxPv
     * @param atk
     */
    protected Sprite(CollisionManager collisionManager, HitBox hitBox, String skin,
                       Color color, int pv, int maxPv, int atk){
        this.collisionManager = collisionManager;
        this.hitBox = hitBox;
        this.color = color;
        this.pv = pv;
        this.maxPv = maxPv;
        this.atk = atk;
        if (skin == "") image = null;
        else image = new Image(skin);
    }

    /**
     * Dit si le joueur est mort ou non
     * @return
     */
    public boolean isDead(){
        return pv <= 0;
    }

    /**
     * Met les pv du Sprite au nombre de pv donné,
     * il ne peut exéder le maximum de pv sous peine d'être set au maximum de pv possible,
     * de même il ne peut être inférieur a 0 sous peine d'être set à 0.
     * @param pv
     */
    public void setPv(int pv) {
        if (pv > maxPv) this.pv = maxPv;
        else if (pv < 0) this.pv = 0;
        else this.pv = pv;
    }

    public Color getColor() {
        return color;
    }
    public CollisionManager getCollisionManager(){
        return collisionManager;
    }
    public HitBox getHitBox() {
        return hitBox;
    }
    public void setPosX(int posX) {
        hitBox.setCoinHautGaucheX(posX);
    }
    public void setPosY(int posY) {
        hitBox.setCoinHautGaucheY(posY);
    }
    public int getPosX() {
        return hitBox.getCoinHautGaucheX();
    }
    public int getPosY() {
        return hitBox.getCoinHautGaucheY();
    }
    public int getCenterX() {
        return hitBox.getCenterX();
    }
    public int getCenterY() {
        return hitBox.getCenterY();
    }
    public int getMaxPv() {
        return maxPv;
    }
    public int getAtk() {
        return atk;
    }
    public int getPv() {
        return pv;
    }
    public Image getImage() {
        return image;
    }
    public boolean isLifeBarEnabled(){
        return enableLifeBar;
    }
    public void setAtk(int atk) {
        this.atk = atk;
    }
}
