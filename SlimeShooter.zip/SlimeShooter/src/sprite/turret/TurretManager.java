package sprite.turret;

import utils.GameScreen;
import sprite.monster.MonsterSprite;
import world.World;

/**
 * Gère toutes les tourelles
 */
public class TurretManager {
    private TurretShooter tourelleShooter;
    private TurretAim turretAim;
    public TurretManager(World world, GameScreen gameScreen){
        tourelleShooter = new TurretShooter(world, gameScreen);
        turretAim = new TurretAim(world);
    }

    /**
     * Fait tirer une tourelle
     * @param tourelle
     * @param monsterSprite
     */
    public void shoot(Turret tourelle, MonsterSprite monsterSprite){
        tourelleShooter.shoot(tourelle, monsterSprite);
    }

    public MonsterSprite aimNearestMonster(Turret tourelle){
        return turretAim.aim(tourelle);
    }
}
