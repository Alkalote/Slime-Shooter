package sprite.turret;

import sprite.monster.MonsterSprite;
import utils.Distance;
import world.World;

/**
 * Vise le monstre le plus proche
 */
public class TurretAim {
    private World world;
    public TurretAim(World world){
        this.world = world;
    }

    /**
     * Cherche le monstre le plus proche et le retourne
     * @param tourelle
     * @return
     */
    public MonsterSprite aim(Turret tourelle){
        MonsterSprite plusProche = null, monsterSpriteActuel;
        int distancePlusProche= -1, distanceCalculee;
        for (int i=1; i<world.getSpritesOnWorld().size(); i++){
            if (world.getSpritesOnWorld().get(i) instanceof MonsterSprite){
                monsterSpriteActuel = (MonsterSprite) world.getSpritesOnWorld().get(i);
                distanceCalculee = Distance.getDistance(tourelle, monsterSpriteActuel);
                if(distancePlusProche == -1){
                    distancePlusProche = distanceCalculee;
                    plusProche = monsterSpriteActuel;
                }
                else if(distanceCalculee < distancePlusProche){
                    distancePlusProche = distanceCalculee;
                    plusProche = monsterSpriteActuel;
                }
            }

        }
        return plusProche;
    }
}
