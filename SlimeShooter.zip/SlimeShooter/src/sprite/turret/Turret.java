package sprite.turret;

import collisions.HitBox;
import collisions.managers.CollisionManager;
import javafx.scene.paint.Color;
import sprite.Sprite;

/**
 * Tourelle automatique, vise l'ennemi le plus proche
 */
public class Turret extends Sprite {
    private static int baseDamage = 1;
    public Turret(int posX, int posY, CollisionManager collisionManager) {
        super(collisionManager, new HitBox(posX, posY, 50, 50), "/skins/tourelle.png",
                Color.GRAY, 100, 100, baseDamage);
    }

    public static int getBaseDamage() {
        return baseDamage;
    }

    public static void setBaseDamage(int baseDamage) {
        Turret.baseDamage = baseDamage;
    }
}
