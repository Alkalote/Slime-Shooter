package sprite.turret;

import utils.GameScreen;
import time.Observateur;
import time.Timer;
import world.World;

/**
 * Fait tirer les tourelles tout les laps de temps
 */
public class TurretTimer implements Observateur {
    private int ticks=0;
    private final World world;
    private final TurretManager turretManager;
    private final int ticksPerSecond;
    private int turretAtkSpeed;
    public TurretTimer(World world, GameScreen gameScreen, Timer timer){
        this.world = world;
        this.turretManager = new TurretManager(world, gameScreen);
        ticksPerSecond = timer.getTicksPerSecond();
        turretAtkSpeed = 2;
    }

    @Override
    public void notification() {
        ticks++;
        if (ticks%(ticksPerSecond/turretAtkSpeed) == 0){
            for (int i = 0; i < world.getSpritesOnWorld().size(); i++) {
                if (!(world.getSpritesOnWorld().get(i) instanceof Turret)) continue;
                turretManager.shoot((Turret) world.getSpritesOnWorld().get(i),
                        turretManager.aimNearestMonster((Turret) world.getSpritesOnWorld().get(i)));
            }
        }
    }

    @Override
    public void end() {

    }

    public int getTurretAtkSpeed() {
        return turretAtkSpeed;
    }

    public void setTurretAtkSpeed(int turretAtkSpeed) {
        this.turretAtkSpeed = turretAtkSpeed;
    }
}
