package sprite.turret;

import collisions.managers.BulletCollisionManager;
import displacer.BulletDisplacer;
import sprite.monster.MonsterSprite;
import sprite.bullets.Bullet;
import utils.GameScreen;
import world.World;

/**
 * Fait tirer une tourelle
 */
public class TurretShooter {
    private World world;
    private BulletCollisionManager bulletCollisionManager;
    private BulletDisplacer bulletDisplacer;
    public TurretShooter(World world, GameScreen gameScreen){
        this.world = world;
        bulletCollisionManager = new BulletCollisionManager();
        bulletDisplacer = new BulletDisplacer(gameScreen);
    }

    /**
     * Fait tirer une tourelle²
     * @param tourelle
     * @param monsterSprite
     */
    public void shoot(Turret tourelle, MonsterSprite monsterSprite){
        if (monsterSprite == null) return;
        world.getSpritesOnWorld().add(new Bullet(tourelle.getCenterX(), tourelle.getCenterY(),
                monsterSprite.getCenterX(), monsterSprite.getCenterY(), tourelle.getAtk(), bulletCollisionManager,
                bulletDisplacer));
    }
}
