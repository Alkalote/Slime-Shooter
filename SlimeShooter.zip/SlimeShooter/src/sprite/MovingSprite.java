package sprite;

import collisions.HitBox;
import collisions.managers.CollisionManager;
import displacer.Displacer;
import javafx.scene.paint.Color;

/**
 * MovingSprite est un sprite qui a la capacité de se déplacer dans le jeu.
 * Vous pouvez choisir l'algorithme de déplacement en donnant un Displacer spécialisé.
 * @see Sprite
 * @see Displacer
 */
public abstract class MovingSprite extends Sprite{
    protected final Displacer displacer;
    private int speed;

    /**
     * MovingSprite est un Sprite mais avec la capacité de bouger,
     * la gestion de ses mouvements est gérée par son Displacer.
     * @param collisionManager
     * @param hitBox
     * @param skin
     * @param color
     * @param pv
     * @param maxPv
     * @param atk
     * @param speed
     * @param displacer
     */
    protected MovingSprite(CollisionManager collisionManager, HitBox hitBox, String skin, Color color,
                           int pv, int maxPv, int atk, int speed, Displacer displacer) {
        super(collisionManager, hitBox, skin, color, pv, maxPv, atk);
        this.displacer = displacer;
        this.speed = speed;
    }

    public int getSpeed(){return speed;}
    public void setSpeed(){this.speed = speed;}
    public void goToMiddleOfScreen(){
        displacer.goToMiddleOfScreen(this);
    }

    /**
     * Le MovingSprite utilise son displacer pour bouger
     * (Conseil : définir canMove et vérifier son retour avant un déplacement)
     */
    public abstract void move();

    /**
     * Le MovingSprite utilise son displacer pour bouger dans la direction opposée entre lui et son objectif donné
     * en paramètre
     * (Conseil : définir canMove et vérifier son retour avant un déplacement)
     */
    public abstract void moveReverse(int objectiveX, int objectiveY);

    /**
     * Vérifie si le MovingSprite peut bouger
     */
    public abstract boolean canMove();

    /**
     * Vérifie si le MovingSprite peut bouger dans la direction opposée a l'objectif donné en paramètre
     * @param objectiveX
     * @param objectiveY
     * @return
     */
    public abstract boolean canMoveReverse(int objectiveX, int objectiveY);
}
