package sprite.player;

import utils.GameScreen;
import sprite.monster.MonsterSprite;
import world.World;

/**
 * Gère un joueur
 */
public class PlayerManager {
    private final Shooter shooter;
    public PlayerManager(World world, GameScreen gameScreen){
        this.shooter = new Shooter(world, gameScreen);
    }

    /**
     * Fait tirer le joueur dans la direction indiquée
     * @param player
     * @param cursorX
     * @param cursorY
     */
    public void shoot(Player player, int cursorX, int cursorY){
        shooter.shoot(player, cursorX, cursorY);
    }

    /**
     * Met un mouvement activé (ex : stafeLeft)
     * @param player
     * @param touche
     */
    public void addMovement(Player player, int touche){
        switch (touche) {
            case 'S': //S
                player.setGoBackwards(true);
                break;
            case 'Q':
                player.setStrafeLeft(true);
                break;
            case 'Z':
                player.setGoForwards(true);
                break;
            case 'D':
                player.setStrafeRight(true);
                break;
        }
    }

    /**
     * Retire un mouvement quand une touche est relachée
     * @param player
     * @param touche
     */
    public void removeMovement(Player player, int touche){
        switch (touche) {
            case 'S': //S
                player.setGoBackwards(false);
                break;
            case 'Q':
                player.setStrafeLeft(false);
                break;
            case 'Z':
                player.setGoForwards(false);
                break;
            case 'D':
                player.setStrafeRight(false);
                break;
        }
    }

    /**
     * Monte le score du joueur
     * @param player
     * @param monsterSprite
     */
    public void upScore(Player player, MonsterSprite monsterSprite){
        player.setScore(player.getScore() + monsterSprite.getScoreValue());
    }

    /**
     * Fait gagner de l'argent au joueur
     * @param player
     * @param monsterSpriteN1
     */
    public void gainMoney(Player player, MonsterSprite monsterSpriteN1) {
        player.setMoney(player.getMoney() + monsterSpriteN1.getMoneyReward());
    }

    /**
     * Fait prendre des dégâts au joueur
     * @param player
     * @param dammage
     */
    public void takeDamage(Player player, int dammage){player.setPv(player.getPv() - dammage);}
}
