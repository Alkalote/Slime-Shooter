package sprite.player;

import utils.GameScreen;
import time.Observateur;
import time.Timer;
import world.World;

/**
 * Fait tirer le joueur si il a la touche de tir enfoncé en fonction du temps qui passe
 */
public class ShooterTimer implements Observateur {
    int ticks =0;
    private PlayerManager playerManager;
    private World world;
    private Player player;
    private int ticksPerSecond;

    public ShooterTimer(World world, Player player, GameScreen gameScreen, Timer timer){
        this.world = world;
        this.player = player;
        playerManager = new PlayerManager(world, gameScreen);
        ticksPerSecond = timer.getTicksPerSecond();
    }

    @Override
    public void notification() {
        int tempsAAttendre;
        ticks++;
        tempsAAttendre = ticksPerSecond - player.getAtkSpeed();
        if (tempsAAttendre <= 0) tempsAAttendre = 1;
        if(ticks%tempsAAttendre == 0 && player.isShoot()){
            playerManager.shoot(player, player.getCurseurX(), player.getCurseurY());
        }
    }

    @Override
    public void end() {

    }
}
