package sprite.player;

import collisions.managers.BulletCollisionManager;
import displacer.BulletDisplacer;
import utils.GameScreen;
import sprite.bullets.Bullet;
import world.World;

/**
 * Gère le shoot du joueur
 */
public class Shooter {
    private World world;
    private BulletCollisionManager bulletCollisionManager;
    private BulletDisplacer bulletDisplacer;

    public Shooter(World world, GameScreen gameScreen){
        this.world = world;
        bulletCollisionManager = new BulletCollisionManager();
        bulletDisplacer = new BulletDisplacer(gameScreen);
    }

    /**
     * Fait direr le joueur dans la direction indiquée
     * @param player
     * @param cursorX
     * @param cursorY
     */
    public void shoot(Player player, int cursorX, int cursorY){
        world.getSpritesOnWorld().add(new Bullet(player.getCenterX(), player.getCenterY(), cursorX, cursorY,
                player.getAtk(), bulletCollisionManager, bulletDisplacer));
    }
}
