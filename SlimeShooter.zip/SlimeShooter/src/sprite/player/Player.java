package sprite.player;

import collisions.HitBox;
import collisions.managers.CollisionManager;
import displacer.Displacer;
import javafx.application.Platform;
import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.scene.paint.Color;
import sprite.MovingSprite;
import utils.SimpleVector;
import utils.SimpleVectorComputer;

/**
 * Définit le joueur du jeu
 */
public class Player extends MovingSprite {

    /**
     * Score du joueur
     */
    private IntegerProperty score = new SimpleIntegerProperty();
        public IntegerProperty getScoreProperty(){ return score; }
        public int getScore(){ return score.get(); }
        public void setScore(int newScore){
            Platform.runLater( () -> score.set(newScore));
        }

    /**
     * Argent du joueur
     */
    private IntegerProperty money = new SimpleIntegerProperty();
        public IntegerProperty getMoneyProperty(){ return money; }
        public int getMoney(){ return money.get(); }
        public void setMoney(int newMoney){
            Platform.runLater(() -> money.set(newMoney));
        }

    private String nom;
    private boolean strafeLeft = false, strafeRight = false, goForwards = false, goBackwards = false;
    private int curseurX, curseurY, atkSpeed, atkSpeedMax;
    private boolean shoot = false;

    /**
     * Constructeur de player
     * @param posX
     * @param posY
     * @param collisionManager
     * @param displacer
     */
    public Player(int posX, int posY, CollisionManager collisionManager, Displacer displacer) {
        super(collisionManager, new HitBox(posX, posY, 50, 50), "/skins/player.png",
                Color.CHOCOLATE, 100, 100, 1, 5, displacer);
        atkSpeed = 10;
        atkSpeedMax = 16;
        enableLifeBar = true;
    }

    /**
     * Déplace le joueur en fonction des touches de direction enfoncées
     */
    @Override
    public void move(){
        if (canMove()) displacer.move(this, computeMovement());
    }

    @Override
    public void moveReverse(int objectiveX, int objectiveY) {

    }

    @Override
    public boolean canMove() {
        return displacer.canMove(this, computeMovement());
    }

    @Override
    public boolean canMoveReverse(int objectiveX, int objectiveY) {
        return false;
    }

    /**
     * Somme les vecteurs générés par l'appui des touches de direction du joueur
     * @return
     */
    private SimpleVector computeMovement(){
        SimpleVector movement = new SimpleVector(0, 0, 0, 0);
        if (goForwards) movement = SimpleVectorComputer.concat2Vectors(movement,
                new SimpleVector(0, 0, 0, -getSpeed()));
        if (goBackwards) movement = SimpleVectorComputer.concat2Vectors(movement,
                new SimpleVector(0, 0, 0, getSpeed()));
        if (strafeLeft) movement = SimpleVectorComputer.concat2Vectors(movement,
                new SimpleVector(0, 0, -getSpeed(), 0));
        if (strafeRight) movement = SimpleVectorComputer.concat2Vectors(movement,
                new SimpleVector(0, 0, getSpeed(), 0));
        return movement;
    }

    public boolean isStrafeRight() {
        return strafeRight;
    }

    public void setStrafeRight(boolean strafeRight) {
        Platform.runLater(() ->this.strafeRight = strafeRight);
    }

    public boolean isGoForwards() {
        return goForwards;
    }

    public void setGoForwards(boolean goForwards) {
        Platform.runLater(() ->this.goForwards = goForwards);
    }

    public boolean isGoBackwards() {
        return goBackwards;
    }

    public void setGoBackwards(boolean goBackwards) {
        Platform.runLater(() ->this.goBackwards = goBackwards);
    }

    public boolean isStrafeLeft() {
        return strafeLeft;
    }

    public void setStrafeLeft(boolean strafeLeft) {
        Platform.runLater(() ->this.strafeLeft = strafeLeft);
    }

    public boolean isShoot() {
        return shoot;
    }

    public int getAtkSpeed() {
        return atkSpeed;
    }

    public void setAtkSpeed(int atkSpeed) {
        if (atkSpeed <= 0) this.atkSpeed = 1;
        else if (atkSpeed > atkSpeedMax) this.atkSpeed = atkSpeedMax;
        this.atkSpeed = atkSpeed;
    }

    public int getAtkSpeedMax() {
        return atkSpeedMax;
    }

    public int getCurseurX() {
        return curseurX;
    }

    public void setCurseurX(int curseurX) {
        this.curseurX = curseurX;
    }

    public int getCurseurY() {
        return curseurY;
    }

    public void setCurseurY(int curseurY) {
        this.curseurY = curseurY;
    }

    public void setShoot(boolean shoot) {
        this.shoot = shoot;
    }

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }
}
