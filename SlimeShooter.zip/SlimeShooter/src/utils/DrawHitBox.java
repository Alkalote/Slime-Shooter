package utils;

import javafx.scene.canvas.Canvas;
import javafx.scene.paint.Color;
import sprite.MovingSprite;
import sprite.Sprite;

/**
 * Classe utilitaire servant au débug des HitBox, dessine des carrés a chaque coin des HitBox de tout les sprites
 */
public class DrawHitBox {
    /**
     * drawHitBox est une classe de débug, elle est très utile pour comprendre ce qui est cassé a chaque fois
     * @param canvas
     * @param sprite
     */
    public static void drawHitBox(Canvas canvas, Sprite sprite){
        //Centre
        canvas.getGraphicsContext2D().setFill(Color.PINK);
        canvas.getGraphicsContext2D().fillRect(sprite.getHitBox().getCenterX(),
                sprite.getHitBox().getCenterY(), 1, 1);

        //Coins
        canvas.getGraphicsContext2D().setFill(Color.PINK);
        canvas.getGraphicsContext2D().fillRect(sprite.getHitBox().getCoinBasDroiteX(),
                sprite.getHitBox().getCoinBasDroiteY(), 5, 5);

        canvas.getGraphicsContext2D().setFill(Color.PINK);
        canvas.getGraphicsContext2D().fillRect(sprite.getHitBox().getCoinHautGaucheX()-5,
                sprite.getHitBox().getCoinHautGaucheY()-5, 5, 5);

        canvas.getGraphicsContext2D().setFill(Color.PINK);
        canvas.getGraphicsContext2D().fillRect(sprite.getHitBox().getCoinHautGaucheX()-5,
                sprite.getHitBox().getCoinBasDroiteY(), 5, 5);

        canvas.getGraphicsContext2D().setFill(Color.PINK);
        canvas.getGraphicsContext2D().fillRect(sprite.getHitBox().getCoinBasDroiteX(),
                sprite.getHitBox().getCoinHautGaucheY()-5, 5, 5);
    }
}
