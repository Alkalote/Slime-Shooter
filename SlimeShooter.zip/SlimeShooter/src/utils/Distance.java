package utils;

import sprite.Sprite;

import static java.lang.Math.abs;
import static java.lang.Math.sqrt;

/**
 * Classe utilitaire qui calcule la distance entre deux Sprites
 * @see Sprite
 */
public class Distance {
    /**
     * Calcule la distance entre deux Sprites
     * @param o1
     * @param o2
     * @return
     */
    public static int getDistance(Sprite o1, Sprite o2){
        int distance;
        if (o1.getCenterX() == 0 && o2.getCenterX() == 0 && o1.getCenterY() == 0 && o2.getCenterY() == 0){
            distance = 0;
        }
        else if (o1.getCenterX() == 0 && o2.getCenterX() == 0){
            distance = abs(abs(o1.getCenterY())-abs(o2.getCenterY()));
        }
        else if ( o1.getCenterY() == 0 && o2.getCenterY() == 0){
            distance = abs(abs(o1.getCenterX())-abs(o2.getCenterX()));
        }
        else{
            //Utilisation du théorème de pythagore.
            int AC2 = abs(abs(o1.getCenterY())-abs(o2.getCenterY()))*abs(abs(o1.getCenterY())-abs(o2.getCenterY()));
            int CB2 = abs(abs(o1.getCenterX())-abs(o2.getCenterX()))*abs(abs(o1.getCenterX())-abs(o2.getCenterX()));
            distance = (int) sqrt(AC2 + CB2);
        }
        return distance;
    }
}
