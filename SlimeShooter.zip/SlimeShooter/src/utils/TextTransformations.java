package utils;

/**
 * Classe qui rassemble toutes les méthodes de manipulation de texte
 */
public class TextTransformations {
    /**
     * Transforme une chaine de caractère en minuscule de un ou pluieurs mots en une chaine de caractère ou chaque mot
     * a une majuscule
     * Exemple:
     * bonjour je suis un test
     * -> Bonjour Je Suis Un Test
     * (méthode tirée d'internet, elle découpe mot a mot la chaine, transforme la première lettre du mot en majuscule
     * puis rajoute derrière cette lettre en majuscule la suite du mot ainsi que un espace.)
     * @param givenString
     * @return
     */
    public static String toTitleCase(String givenString) {
        String[] arr = givenString.split(" ");
        StringBuffer sb = new StringBuffer();

        for (String s : arr) {
            sb.append(Character.toUpperCase(s.charAt(0)))
                    .append(s.substring(1)).append(" ");
        }
        return sb.toString().trim();
    }
}
