package utils;

import collisions.GeneralCollisionner;
import displacer.GeneralDisplacer;
import sprite.Sprite;
import sprite.bullets.Bullet;
import time.Observateur;
import world.World;

/**
 * Gère toute la physique du jeu (collisions, déplacements)
 */
public class PhysicsManagerTimer implements Observateur {
    private World world;
    private GeneralCollisionner generalCollisionner;
    private GameScreen gameScreen;
    public PhysicsManagerTimer(World world, GameScreen gameScreen){
        this.world = world;
        generalCollisionner = new GeneralCollisionner(world);
    }

    /**
     * Applique la physique du jeu toutes les nouvelle notifications
     */
    @Override
    public void notification() {
        Sprite actualSprite;
        for (int i=0; i < world.getSpritesOnWorld().size(); i++){
            actualSprite = world.getSpritesOnWorld().get(i);
            GeneralDisplacer.moveThisSprite(actualSprite);
            generalCollisionner.doCollisionsWithOthers(actualSprite);
            if (actualSprite instanceof Bullet){
                if (!((Bullet)actualSprite).canMove()) world.getSpritesOnWorld().remove(actualSprite);
            }
        }
    }

    @Override
    public void end() {

    }
}
