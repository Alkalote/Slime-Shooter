package utils;

/**
 * Vecteur simplifié, il se calcule a partir de deux points
 */
public class SimpleVector {
    private final int startX;
    private final int startY;
    private final int endX;
    private final int endY;
    private final int longX;
    private final int longY;
    private final double longTot;
    private final double normUnitX;
    private final double normUnitY;

    /**
     * SimpleVector calcule un vecteur entre les points de start et de end dès sa construction,
     * la version normalisée (unitaire) du vecteur est également calculée.
     * @param startX
     * @param startY
     * @param endX
     * @param endY
     */
    public SimpleVector(int startX, int startY, int endX, int endY){
        this.startX = startX;
        this.startY = startY;
        this.endX = endX;
        this.endY = endY;

        longX = endX - startX;
        longY = endY - startY;
        longTot = Math.sqrt(longX*longX + longY*longY);
        if (longTot == 0){
            normUnitX = 0;
            normUnitY = 0;
        }
        else {
            normUnitX = longX / longTot;
            normUnitY = longY / longTot;
        }
    }


    public int getLongX() {
        return longX;
    }

    public int getLongY() {
        return longY;
    }

    public int getStartX() {
        return startX;
    }

    public int getStartY() {
        return startY;
    }

    public int getEndX() {
        return endX;
    }

    public int getEndY() {
        return endY;
    }

    public double getLongTot() {
        return longTot;
    }

    public double getNormUnitX() {
        return normUnitX;
    }

    public double getNormUnitY() {
        return normUnitY;
    }
}
