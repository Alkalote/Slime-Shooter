package utils;

/**
 * Rassemble toutes les méthodes de calcul concernant les SimpleVectors
 * @see SimpleVector
 */
public class SimpleVectorComputer {
    /**
     * Concatène deux vecteurs pour en obtenir un seul
     * @param v1
     * @param v2
     * @return
     */
    public static SimpleVector concat2Vectors(SimpleVector v1, SimpleVector v2){
        return new SimpleVector(v1.getStartX(), v2.getStartY(),
                v1.getLongX() + v2.getLongX(), v1.getLongY() + v2.getLongY());
    }
}
