package utils;

import javafx.scene.Scene;

/**
 * Définit l'écran de jeu, sert beaucoup pour tester une sortie d'écran
 */
public class GameScreen {
    private int xMax, yMax;

    /**
     * Constructeur de GameScreen
     * @param xMax coin bas droit de l'écran
     * @param yMax coin bas droit de l'écran
     */
    public GameScreen(int xMax, int yMax){
        this.xMax = xMax;
        this.yMax = yMax;
    }

    /**
     * Dit si les positions données se situent en dehors de l'écran
     * @param posX
     * @param posY
     * @return
     */
    public boolean outOfScreen(int posX, int posY){
        return posX <= 0 || posX >= xMax || posY <= 0 || posY >= yMax;
    }

    public int getxMax() {
        return xMax;
    }

    public int getyMax() {
        return yMax;
    }

    public void setxMax(int xMax) {
        this.xMax = xMax;
    }

    public void setyMax(int yMax) {
        this.yMax = yMax;
    }
}
