package graphics;

import javafx.scene.canvas.Canvas;
import javafx.scene.image.Image;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Text;
import sprite.player.Player;
import time.Observateur;
import utils.DrawHitBox;
import world.World;

/**
 * Dessine tout les Sprites de World toutes les notifications
 * @see World
 */
public class DrawerTimer implements Observateur {
    private final Player player;
    private final World world;
    private final Drawer drawer;
    private final Canvas canvas;
    private final Text text;
    private final VBox vbox;

    public DrawerTimer(Player player, World world, Canvas canvas, Text text, VBox vbox){
        this.player = player;
        this.world = world;
        this.canvas = canvas;
        this.text = text;
        this.vbox = vbox;
        drawer = new Drawer(canvas.getGraphicsContext2D());
    }

    /**
     * Dessine tout les sprites sur le canvas
     */
    @Override
    public void notification() {
        canvas.getGraphicsContext2D().clearRect(0, 0, canvas.getWidth(), canvas.getHeight());
        canvas.getGraphicsContext2D().setFill(Color.DARKOLIVEGREEN);
        canvas.getGraphicsContext2D().fillRect(0, 0, canvas.getWidth(), canvas.getHeight());
        world.getSpritesOnWorld().forEach(sprite -> {
            //DrawHitBox.drawHitBox(canvas, sprite);
            if(sprite.getImage() == null){
                drawer.drawSpriteCircleColor(sprite, sprite.getColor());
            }
            else{
                drawer.drawSpriteSkin(sprite);
            }
            if (sprite.isLifeBarEnabled()){
                drawer.drawLifeBar(sprite);
            }
        });
    }

    /**
     * Affiche l'écran de game over
     */
    @Override
    public void end() {
        vbox.setVisible(true);
        text.textProperty().bind(player.getScoreProperty().asObject().asString());
    }
}
