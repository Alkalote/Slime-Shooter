package graphics;

import javafx.scene.canvas.GraphicsContext;
import javafx.scene.image.Image;
import javafx.scene.paint.Color;
import sprite.Sprite;
import sprite.monster.MonsterSprite;
import sprite.player.Player;
import sprite.MovingSprite;

/**
 * Classe qui s'occupe de dessiner tout les sprite sur un Canevas
 */
public class Drawer {
    private GraphicsContext gc;
    public Drawer(GraphicsContext gc){
        this.gc = gc;
    }

    /**
     * Dessine un cercle de la couleur définie par le Sprite dessiné et de la taille du Sprite dessiné
     * @param sprite
     * @param color
     */
    public void drawSpriteCircleColor(Sprite sprite, Color color){
        gc.setFill(color);
        gc.fillOval(sprite.getPosX(), sprite.getPosY(), sprite.getHitBox().getTailleHitBoxX(),
                sprite.getHitBox().getTailleHitBoxY());
        if (sprite instanceof Player || sprite instanceof MonsterSprite){
            gc.setFill(Color.DARKRED);
            gc.fillRoundRect(sprite.getPosX(), sprite.getPosY() - 15, sprite.getHitBox().getTailleHitBoxX(),
                    10, 15, 15);
            gc.setFill(Color.DARKGREEN);
            gc.fillRoundRect(sprite.getPosX(), sprite.getPosY() - 15,
                    (int)(sprite.getHitBox().getTailleHitBoxX()*((float) sprite.getPv()/(float) sprite.getMaxPv())),
                    10, 15, 15);
        }
    }

    /**
     * Dessine la barre de vie d'un sprite
     * @param sprite
     */
    public void drawLifeBar(Sprite sprite){
        gc.setFill(Color.DARKRED);
        gc.fillRoundRect(sprite.getPosX(), sprite.getPosY() - 15, sprite.getHitBox().getTailleHitBoxX(),
                    10, 15, 15);
        gc.setFill(Color.DARKGREEN);
        gc.fillRoundRect(sprite.getPosX(), sprite.getPosY() - 15,
                    (int)(sprite.getHitBox().getTailleHitBoxX()*((float) sprite.getPv()/(float) sprite.getMaxPv())),
                    10, 15, 15);
        gc.setFill(Color.WHITE);
        gc.fillText(sprite.getPv() + "/" + sprite.getMaxPv(),
                sprite.getPosX()+2, sprite.getPosY() - 6);
    }

    /**
     * Dessine le skin d'un sprite, de la taille de ce sprite
     * @param sprite
     */
    public void drawSpriteSkin(Sprite sprite){
        gc.drawImage(sprite.getImage(), sprite.getPosX(), sprite.getPosY(),
                sprite.getHitBox().getTailleHitBoxX(), sprite.getHitBox().getTailleHitBoxY());
    }
}
