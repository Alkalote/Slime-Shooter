package utilsbinding;

import javafx.scene.input.KeyCode;

import java.io.Serializable;

/**
 * Classe qui contient la valeur en String et en KeyCode d'une touche de clavier
 */
public class ButtonData implements Serializable {

    private String buttStr ;
    private KeyCode buttCode;

    public ButtonData(String butStr,KeyCode butCode){
        this.buttCode = butCode;
        this.buttStr = butStr;

    }

    public ButtonData(){
        this.buttCode = null;
        this.buttStr = null;
    }

    public String getButtStr() {
        return buttStr;
    }

    public void setButtStr(String buttStr) {
        this.buttStr = buttStr;
    }

    public KeyCode getButtCode() {
        return buttCode;
    }

    public void setButtCode(KeyCode buttCode) {
        this.buttCode = buttCode;
    }
}
