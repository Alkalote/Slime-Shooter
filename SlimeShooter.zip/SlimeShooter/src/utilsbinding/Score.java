package utilsbinding;

import java.io.Serializable;

/**
 * Classe contenant le score et le nom d'un joueur
 */
public class Score implements Serializable {

    private int scorePlayer;
    private String nomPlayer;

    public Score(){
        this.scorePlayer = 0;
        this.nomPlayer = "";
    }

    public Score(int score, String nom){
        this.scorePlayer = score;
        this.nomPlayer = nom;
    }


    public int getScorePlayer() {
        return scorePlayer;
    }

    public void setScorePlayer(int scorePlayer) {
        this.scorePlayer = scorePlayer;
    }

    public String getNomPlayer() {
        return nomPlayer;
    }

    public void setNomPlayer(String nomPlayer) {
        this.nomPlayer = nomPlayer;
    }
}
