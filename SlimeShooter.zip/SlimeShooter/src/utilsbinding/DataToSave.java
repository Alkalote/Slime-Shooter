package utilsbinding;


import java.io.Serializable;

/**
 * Classe permettant la sérialisation de plusieurs "touches" (button_data) afin de les récupérer pour gérer les contrôles de déplacement du personnage (haut,bas,gauche,droite)
 */
public class DataToSave implements Serializable {
    private ButtonData butAv;
    private ButtonData butRec;
    private ButtonData butGac;
    private ButtonData butDro;



    public DataToSave(ButtonData Av, ButtonData Re, ButtonData Ga, ButtonData Dr){

        this.butAv = Av;
        this.butRec = Re;
        this.butGac = Ga;
        this.butDro = Dr;

    }

    public DataToSave(){
        this.butAv = new ButtonData();
        this.butRec = new ButtonData();
        this.butGac = new ButtonData();
        this.butDro = new ButtonData();
    }


    public ButtonData getButAv() {
        return butAv;
    }

    public void setButAv(ButtonData butAv) {
        this.butAv = butAv;
    }

    public ButtonData getButRec() {
        return butRec;
    }

    public void setButRec(ButtonData butRec) {
        this.butRec = butRec;
    }

    public ButtonData getButGac() {
        return butGac;
    }

    public void setButGac(ButtonData butGac) {
        this.butGac = butGac;
    }

    public ButtonData getButDro() {
        return butDro;
    }

    public void setButDro(ButtonData butDro) {
        this.butDro = butDro;
    }
}