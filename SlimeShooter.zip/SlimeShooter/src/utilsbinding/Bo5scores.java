package utilsbinding;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 * Classe qui contient une liste de scores initialement 5, créée pour permettre la serialisation des 5 meilleurs scores qui seront affichés
 */
public class Bo5scores implements Serializable {

    private List<Score> lsco;


    public Bo5scores() {
        this.lsco = new ArrayList<>(5);
    }



    public List<Score> getLsco() {
        return lsco;
    }

    public void setLsco(List<Score> lsco) {
        this.lsco = lsco;
    }
}
