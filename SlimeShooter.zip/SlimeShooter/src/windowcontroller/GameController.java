package windowcontroller;

import collisions.managers.PlayerCollisionManager;
import displacer.PlayerDisplacer;
import graphics.DrawerTimer;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import persist.ScoreLoader;
import persist.ScoreSaver;
import sprite.player.Player;
import sprite.player.PlayerManager;
import sprite.player.ShooterTimer;
import sprite.turret.TurretTimer;
import time.Runner;
import time.Timer;
import trade.Article;
import trade.ArticleTypes;
import trade.BuyButtonTimer;
import trade.TraderSetup;
import trade.concret.*;
import utils.GameScreen;
import utils.PhysicsManagerTimer;
import utilsbinding.Bo5scores;
import utilsbinding.Score;
import waves.WaveTimer;
import world.World;
import world.WorldTimer;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

/**
 * Controller responsable de game.fxml
 */
public class GameController {
    @FXML
    private Button upgradeTurretDamage;
    @FXML
    private Button upgradeTurretAtkSpeed;
    @FXML
    private Button placeTurret;
    @FXML
    private Label affichageNextWave;
    @FXML
    private Label affichageTimeAlive;
    @FXML
    private Canvas canvas;
    @FXML
    private Button upgradeAtkSpeed;
    @FXML
    private Button upgradeDamage;
    @FXML
    private Label affichageScore;
    @FXML
    private Label affichageMoney;
    @FXML
    private Label affichageNumVague;

    @FXML
    private VBox DefBox;
    @FXML
    private Text score;
    @FXML
    private TextField Field;



    private Player player;
    private World world;
    private PlayerManager playerManager;

    private TraderSetup traderSetup;


    private Runner runner;

    /*private final IntegerProperty posXCursorProperty;
        public final IntegerProperty posXCursorPropertyProperty(){ return posXCursorProperty; }
        public final int getPosXCursor() { return posXCursorProperty.get(); }
        public final void setPosXCursor(int posXCursor) { posXCursorProperty.set(posXCursor); }*/


    public void initialize(){
        GraphicsContext gc = canvas.getGraphicsContext2D();
        GameScreen gameScreen = new GameScreen((int) canvas.getWidth(), (int) canvas.getHeight());
        DefBox.setVisible(false);
        world = new World();
        playerManager = new PlayerManager(world, gameScreen);
        player =  new Player(500, 500, new PlayerCollisionManager(playerManager),
                new PlayerDisplacer(gameScreen));
        world.getSpritesOnWorld().add(player);

        runner = new Runner(true);
        Timer timer = new Timer(1, runner, 20);

        canvas.setOnMousePressed(action -> {
            player.setCurseurX((int) action.getX());
            player.setCurseurY((int) action.getY());
            player.setShoot(true);//pas ouf
        });

        canvas.setOnMouseReleased(action -> {
            player.setShoot(false);//pas ouf
        });

        canvas.setOnMouseDragged(action -> {
            player.setCurseurX((int) action.getX());
            player.setCurseurY((int) action.getY());
        });

        final DrawerTimer drawerTimer = new DrawerTimer(player, world, canvas, score, DefBox);
        final ShooterTimer shooterTimer = new ShooterTimer(world, player, gameScreen, timer);
        final TurretTimer tourelleTimer = new TurretTimer(world, gameScreen, timer);
        final WaveTimer waveTimer = new WaveTimer(world, gameScreen, player, timer);
        final WorldTimer worldTimer = new WorldTimer(world, player, gameScreen, runner, timer.getTicksPerSecond());//A CHANGER
        final PhysicsManagerTimer physicsManagerTimer = new PhysicsManagerTimer(world, gameScreen);

        timer.addObserver(physicsManagerTimer);
        timer.addObserver(drawerTimer);
        timer.addObserver(shooterTimer);
        timer.addObserver(tourelleTimer);
        timer.addObserver(waveTimer);
        timer.addObserver(worldTimer);

        Map<Article, Button> articles = new HashMap<>();
        articles.put(new ArticleUpAtkSpeed(), upgradeAtkSpeed);
        articles.put(new ArticleUpDamage(), upgradeDamage);
        articles.put(new ArticlePlaceTurret(world, gameScreen), placeTurret);
        articles.put(new ArticleUpTurretAtkSpeed(tourelleTimer), upgradeTurretAtkSpeed);
        articles.put(new ArticleUpTurretDamage(world), upgradeTurretDamage);
        traderSetup = new TraderSetup(player, articles);
        final BuyButtonTimer buyButtonTimer = new BuyButtonTimer(traderSetup);
        timer.addObserver(buyButtonTimer);

        timer.start();

        //world.getSpritesOnWorld().add(new Tourelle(100, 600, new DefaultCollisionManager()));

        affichageScore.textProperty().bind(player.getScoreProperty().asObject().asString());
        affichageMoney.textProperty().bind(player.getMoneyProperty().asObject().asString());
        affichageNumVague.textProperty().bind(waveTimer.getWaveData().getWaveNumberProperty().asObject().asString());
        affichageTimeAlive.textProperty().bind(worldTimer.getTimeAliveProperty());
        affichageNextWave.textProperty().bind(waveTimer.getTimeNextWaveProperty());
    }

    public Runner getRunner() {
        return runner;
    }

    public Player getPlayer() {
        return player;
    }

    public World getWorld() {
        return world;
    }

    public PlayerManager getPlayerManager() {
        return playerManager;
    }

    public Canvas getCanvas() {
        return canvas;
    }


    public void upgradeAtkSpeed(ActionEvent actionEvent) {
        traderSetup.buyArticle(ArticleTypes.UP_ATTACK_SPEED);
    }

    public void upgradeDamage(ActionEvent actionEvent) {
        traderSetup.buyArticle(ArticleTypes.UP_DAMAGE);
    }

    public void placeTurret(ActionEvent actionEvent) { traderSetup.buyArticle(ArticleTypes.PLACE_TURRET);}

    public void upgradeTurretAtkSpeed(ActionEvent actionEvent) {
        traderSetup.buyArticle(ArticleTypes.UP_TURRET_ATK_SPEED);
    }

    public void upgradeTurretDamage(ActionEvent actionEvent) {
        traderSetup.buyArticle(ArticleTypes.UP_TURRET_DAMAGE);
    }


    /**
     * Méthode pour rejouer et appeler la méthode de sauvegarde pour sauvegarder ou non le score du joueur
     * @param actionEvent clic bouton
     * @throws IOException
     */
    @FXML
    private void playAgain(ActionEvent actionEvent) throws IOException {

        saveScore();

        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/fxml/game.fxml"));
        Parent gameParent = fxmlLoader.load();
        GameController gameController = fxmlLoader.getController();
        Stage stage = ((Stage) ((Node)actionEvent.getSource()).getScene().getWindow());

        stage.setScene(new Scene(gameParent));

        stage.setOnCloseRequest(action -> {
            gameController.getRunner().setRun(false);
            System.out.println("close !");
        });

        stage.getScene().setOnKeyPressed(action ->
                gameController.getPlayerManager().addMovement(gameController.getPlayer(), action.getCode().getCode()));

        stage.getScene().setOnKeyReleased(action ->
                gameController.getPlayerManager().removeMovement(gameController.getPlayer(), action.getCode().getCode()));
    }

    /**
     * Méthode pour changer de scène pour la scène des meilleurs scores ainsi que l'appel à la méthode de sauvegarde pour sauvegarder ou non le score du joueur
     * @throws IOException
     */
    @FXML
    private void tabScores (ActionEvent actionEvent) throws IOException {

        saveScore();

        Parent parent = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("/fxml/bestScores.fxml")));

        Node node = (Node) actionEvent.getSource();
        Stage thisStage = (Stage) node.getScene().getWindow();
        Scene main = new Scene(parent);
        thisStage.setScene(main);

    }

    /**
     * Méthode pour déterminer le plus grand score des deux donnés
     * @param sc1 premier score
     * @param sc2 second score
     * @return true si sc1 est plus grand et false sinon
     */
    private boolean scoreTestBigger(Score sc1, Score sc2){

        if (sc1.getScorePlayer() > sc2.getScorePlayer()){
            return true;
        }
        return false;
    }

    /**
     * Méthode pour sauvegarder une liste de 5 scores au maximum via la classe ScoreSaver ainsi que de vérifier avant tout si le score du joueur qui vient de finir sa partie est plus grand qu'un autre ou non
     * @throws FileNotFoundException
     */
    private void saveScore() throws FileNotFoundException {

        Score playScore;
        if (Field.getText().equals("")){
            playScore = new Score(player.getScore(),"Guest");
        }
        else
        {
            playScore = new Score(player.getScore(),Field.getText());
        }


        Bo5scores scoreList = chargerScore();


        if(scoreList == null){
            scoreList = new Bo5scores();
        }

        if (scoreList.getLsco().isEmpty() ){
            scoreList.getLsco().add(playScore);
        }
        else if (scoreList.getLsco().size() <5 ){

            int size = scoreList.getLsco().size();
            int i = 0;

            while (i <=size){

                if (scoreTestBigger(playScore,scoreList.getLsco().get(i))){

                    break;
                }
                i = i +1;
            }

            scoreList.getLsco().add( i, playScore);

        }
        else if(scoreList.getLsco().size() == 5){

            if (scoreTestBigger(playScore,scoreList.getLsco().get(0))){

                scoreList.getLsco().remove(4);
                scoreList.getLsco().add(0, playScore);
            }
            else if (scoreTestBigger(playScore,scoreList.getLsco().get(1))){

                scoreList.getLsco().remove(4);
                scoreList.getLsco().add(1, playScore);
            }
            else if (scoreTestBigger(playScore,scoreList.getLsco().get(2))){

                scoreList.getLsco().remove(4);
                scoreList.getLsco().add(2, playScore);
            }
            else if (scoreTestBigger(playScore,scoreList.getLsco().get(3))){

                scoreList.getLsco().remove(4);
                scoreList.getLsco().add(3, playScore);
            }
            else if (scoreTestBigger(playScore,scoreList.getLsco().get(4))){

                scoreList.getLsco().remove(4);
                scoreList.getLsco().add(4, playScore);
            }
        }

        ScoreSaver saver = new ScoreSaver("./bestScores.xml");

        saver.saveScores(scoreList);

    }

    /**
     * Méthode qui permet de récupérer les données chargées avant dans un fichier grâce à la classe ScoreLoader
     * @return un bo5scores du fichier demandé si il existe
     * @throws FileNotFoundException si le fichier n'existe pas une
     */
    public Bo5scores chargerScore() throws FileNotFoundException {

        ScoreLoader loader = new ScoreLoader("./bestScores.xml");
        return loader.loadScores();

    }


}
