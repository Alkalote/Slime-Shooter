package windowcontroller;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import utilsbinding.Bo5scores;
import utilsbinding.Score;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Objects;

/**
 * Controller responsable de bestScores.fxml
 */
public class BestScoresController {
    /**
     * nom du meilleur joueur
     */
    @FXML
    public Text b1name;
    /**
     * score du meilleur joueur
     */
    @FXML
    public Text b1score;

    /**
     * Même structure pour le reste en descendant en places et jusqu'a 5
     */

    @FXML
    private Text b2name;
    @FXML
    private Text b2score;
    @FXML
    private Text b3name;
    @FXML
    private Text b3score;
    @FXML
    private Text b4name;
    @FXML
    private Text b4score;
    @FXML
    private Text b5name;
    @FXML
    private Text b5score;


    /**
     * Méthode qui permet de changer de scène vers la scène de menu
     * @param actionEvent un clic sur un bouton
     * @throws IOException si la scène est inconnue
     */
    @FXML
    private void retMenu (ActionEvent actionEvent) throws IOException {

        Parent parent = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("/fxml/menu.fxml")));

        Node node = (Node) actionEvent.getSource();
        Stage thisStage = (Stage) node.getScene().getWindow();
        Scene main = new Scene(parent);
        thisStage.setScene(main);


    }

    /**
     * Méthode permettant de charger les meilleurs scores dans le tableau des scores (pas dynamique)
     * @param actionEvent un clic sur un bouton
     * @throws FileNotFoundException Si un fichier au nom demandé n'existe pas
     */
    @FXML
    private void chargToTabl (ActionEvent actionEvent) throws FileNotFoundException {

        GameController t= new GameController();
        Bo5scores test = t.chargerScore();
        showScores(test);

    }


    /**
     * Méthode permettant d'afficher des scores en fonction des données reçues dans "s" et en fonction de la taille de "s"
     * @param s Est la liste des meilleurs scores
     */
    private void showScores (Bo5scores s){

        int nb =s.getLsco().size();

        Score s1;
        Score s2;
        Score s3;
        Score s4;
        Score s5;

        switch (nb) {
            case 1 -> {
                s1 = s.getLsco().get(0);
                b1name.setText(s1.getNomPlayer());
                b1score.setText(String.valueOf(s1.getScorePlayer()));
            }
            case 2 -> {
                s1 = s.getLsco().get(0);
                s2 = s.getLsco().get(1);

                b1name.setText(s1.getNomPlayer());
                b1score.setText(String.valueOf(s1.getScorePlayer()));

                b2name.setText(s2.getNomPlayer());
                b2score.setText(String.valueOf(s2.getScorePlayer()));
            }
            case 3 -> {
                s1 = s.getLsco().get(0);
                s2 = s.getLsco().get(1);
                s3 = s.getLsco().get(2);

                b1name.setText(s1.getNomPlayer());
                b1score.setText(String.valueOf(s1.getScorePlayer()));

                b2name.setText(s2.getNomPlayer());
                b2score.setText(String.valueOf(s2.getScorePlayer()));

                b3name.setText(s3.getNomPlayer());
                b3score.setText(String.valueOf(s3.getScorePlayer()));
            }
            case 4 -> {
                s1 = s.getLsco().get(0);
                s2 = s.getLsco().get(1);
                s3 = s.getLsco().get(2);
                s4 = s.getLsco().get(3);

                b1name.setText(s1.getNomPlayer());
                b1score.setText(String.valueOf(s1.getScorePlayer()));

                b2name.setText(s2.getNomPlayer());
                b2score.setText(String.valueOf(s2.getScorePlayer()));

                b3name.setText(s3.getNomPlayer());
                b3score.setText(String.valueOf(s3.getScorePlayer()));

                b4name.setText(s4.getNomPlayer());
                b4score.setText(String.valueOf(s4.getScorePlayer()));
            }
            case 5 -> {
                s1 = s.getLsco().get(0);
                s2 = s.getLsco().get(1);
                s3 = s.getLsco().get(2);
                s4 = s.getLsco().get(3);
                s5 = s.getLsco().get(4);

                b1name.setText(s1.getNomPlayer());
                b1score.setText(String.valueOf(s1.getScorePlayer()));

                b2name.setText(s2.getNomPlayer());
                b2score.setText(String.valueOf(s2.getScorePlayer()));

                b3name.setText(s3.getNomPlayer());
                b3score.setText(String.valueOf(s3.getScorePlayer()));

                b4name.setText(s4.getNomPlayer());
                b4score.setText(String.valueOf(s4.getScorePlayer()));

                b5name.setText(s5.getNomPlayer());
                b5score.setText(String.valueOf(s5.getScorePlayer()));
            }
            default -> {
            }
        }

    }



}
