package windowcontroller;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.IOException;
import java.util.Objects;

/**
 * Controller responsable de menu.fxml
 */
public class MenuController {
    /**
     * Méthode permettant d'accèder aux controles
     * @param actionEvent un clic sur un bouton
     * @throws IOException
     */
    @FXML
    private void goBinds(ActionEvent actionEvent) throws IOException {
        Parent parent2 = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("/fxml/bindings.fxml")));

        Node node = (Node) actionEvent.getSource();
        Stage thisStage = (Stage) node.getScene().getWindow();
        Scene binds = new Scene(parent2);
        thisStage.setScene(binds);

    }

    /**
     * Méthode permettant de lancer le jeu
     * @param actionEvent un clic sur un bouton
     * @throws IOException
     */
    @FXML
    private void goPlay(ActionEvent actionEvent) throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/fxml/game.fxml"));
        Parent gameParent = fxmlLoader.load();
        GameController gameController = fxmlLoader.getController();
        Stage stage = ((Stage) ((Node)actionEvent.getSource()).getScene().getWindow());

        stage.setScene(new Scene(gameParent));

        stage.setOnCloseRequest(action -> {
            gameController.getRunner().setRun(false);
            System.out.println("close !");
        });

        stage.getScene().setOnKeyPressed(action ->
                gameController.getPlayerManager().addMovement(gameController.getPlayer(), action.getCode().getCode()));

        stage.getScene().setOnKeyReleased(action ->
                gameController.getPlayerManager().removeMovement(gameController.getPlayer(), action.getCode().getCode()));
    }


    /**
     * Méthode permettant d'accèder au tableau des scores
     * @param actionEvent un clic sur un bouton
     * @throws IOException
     */
    @FXML
    private void tabBestScores (ActionEvent actionEvent) throws IOException {

        Parent parent = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("/fxml/bestScores.fxml")));

        Node node = (Node) actionEvent.getSource();
        Stage thisStage = (Stage) node.getScene().getWindow();
        Scene main = new Scene(parent);
        thisStage.setScene(main);


    }

}


