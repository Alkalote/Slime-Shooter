package windowcontroller;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.ToggleButton;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.stage.Stage;
import persist.BindLoader;
import persist.BindSaver;
import utilsbinding.ButtonData;
import utilsbinding.DataToSave;

import java.io.IOException;
import java.util.Objects;

/**
 * Controller responsable de bindings.fxml
 */
public class BindingController {
    /**
     * Tout les boutons ainsi que leur code associé
     */

    @FXML
    private ToggleButton toggleButtonAvancer;
    private KeyCode Av;
    @FXML
    private ToggleButton toggleButtonReculer;
    private KeyCode Re;
    @FXML
    private ToggleButton toggleButtonDroite;
    private KeyCode Dr;
    @FXML
    private ToggleButton toggleButtonGauche;
    private KeyCode Ga;

    /**
     * Méthode de retour au menu
     * @param actionEvent un clic sur un bouton
     * @throws IOException si la scène n'existe pas
     */
    @FXML
    private void goMenu(ActionEvent actionEvent) throws IOException {

        Parent parent = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("/fxml/menu.fxml")));

        Node node = (Node) actionEvent.getSource();
        Stage thisStage = (Stage) node.getScene().getWindow();
        Scene main = new Scene(parent);
        thisStage.setScene(main);


    }

    /**
     * Méthode permettant de changer de touche en fonction de la touche pressée "actionEvent" et de si un Bouton ou non est focus et sélectionné
     * @param actionEvent la touche pressée
     * @throws IOException
     */
    @FXML
    private void changeTouche(KeyEvent actionEvent) throws IOException{

        if (toggleButtonAvancer.isSelected() && toggleButtonAvancer.isFocused()){

            toggleButtonAvancer.setText(String.valueOf(actionEvent.getCode()));
            this.Av = actionEvent.getCode();
            toggleButtonAvancer.setSelected(false);
        }
        else if (toggleButtonReculer.isSelected() && toggleButtonReculer.isFocused()){

            toggleButtonReculer.setText(String.valueOf(actionEvent.getCode()));
            this.Re = actionEvent.getCode();
            toggleButtonReculer.setSelected(false);

        }
        else if (toggleButtonDroite.isSelected() && toggleButtonDroite.isFocused()){

            toggleButtonDroite.setText(String.valueOf(actionEvent.getCode()));
            this.Dr = actionEvent.getCode();
            toggleButtonDroite.setSelected(false);
        }
        else if (toggleButtonGauche.isSelected() && toggleButtonGauche.isFocused()){

            toggleButtonGauche.setText(String.valueOf(actionEvent.getCode()));
            this.Ga = actionEvent.getCode();
            toggleButtonGauche.setSelected(false);
        }

    }

    /**
     * Méthode pour sauvegarder les binds dans un fichier XML
     * @param actionEvent un clic sur un bouton
     * @throws IOException
     */
    @FXML
    private void sauvegarderBinds(ActionEvent actionEvent) throws IOException {

        ButtonData Av = new ButtonData(String.valueOf(this.Av),this.Av);
        ButtonData Re = new ButtonData(String.valueOf(this.Re),this.Re);
        ButtonData Ga = new ButtonData(String.valueOf(this.Ga),this.Ga);
        ButtonData Dr = new ButtonData(String.valueOf(this.Dr),this.Dr);

            DataToSave data = new DataToSave(Av,Re,Ga,Dr);


            BindSaver saver = new BindSaver("./binds.xml");

            saver.saveBinds(data);


    }

    /**
     * Méthode pour charger les binds d'un fichier XML
     */
    @FXML
    private void chargerBinds(){

        try {

            BindLoader loader = new BindLoader("./binds.xml");

            DataToSave data = loader.chargerBinds();

            ButtonData Ava = data.getButAv();
            ButtonData Rec = data.getButRec();
            ButtonData Gac = data.getButGac();
            ButtonData Dro = data.getButDro();

            toggleButtonAvancer.setText(Ava.getButtStr());
            this.Av = Ava.getButtCode();
            toggleButtonReculer.setText(Rec.getButtStr());
            this.Re = Rec.getButtCode();
            toggleButtonGauche.setText(Gac.getButtStr());
            this.Ga = Gac.getButtCode();
            toggleButtonDroite.setText(Dro.getButtStr());
            this.Dr = Dro.getButtCode();

        } catch (final Exception e) {
            e.printStackTrace();
        }
    }

    public KeyCode getAv() {
        return Av;
    }

    public void setAv(KeyCode av) {
        Av = av;
    }

    public KeyCode getRe() {
        return Re;
    }

    public void setRe(KeyCode re) {
        Re = re;
    }

    public KeyCode getDr() {
        return Dr;
    }

    public void setDr(KeyCode dr) {
        Dr = dr;
    }

    public KeyCode getGa() {
        return Ga;
    }

    public void setGa(KeyCode ga) {
        Ga = ga;
    }
}