package trade;

import sprite.player.Player;

import java.util.ArrayList;
import java.util.List;

/**
 * S'occupe de faire acheter l'article demandé au joueur donné au constructeur.
 */
public class Buyer {
    private Player player;
    private List<Article> catalog;

    public Buyer(Player player){
        this.player = player;
        catalog = new ArrayList<>();
    }

    /**
     * Fait acheter l'article demandé au joueur, attention, si l'article demandé ne figure pas dans
     * le catalogue, renvoie une exception.
     * @param articleBuyed
     */
    public void buyArticle(ArticleTypes articleBuyed){
        for (Article product : catalog) {
            if (product.getId() == articleBuyed) {
                product.buyTheArticle(player);
                return;
            }
        }
        throw new IllegalArgumentException("L'article passé en paramètre n'est pas renseigné dans le catalogue");
    }

    /**
     * Ajoute un article au catalogue.
     * @param article
     */
    public void addArticleToCatalog(Article article){
        catalog.add(article);
    }

    /**
     * Update le style des boutons d'achat
     */
    public void updateStyleOfAllArticles(){
        catalog.forEach(article -> article.updateButton(player));
    }
}
