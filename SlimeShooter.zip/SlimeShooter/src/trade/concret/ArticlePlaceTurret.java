package trade.concret;

import collisions.managers.DefaultCollisionManager;
import utils.GameScreen;
import sprite.player.Player;
import sprite.turret.Turret;
import trade.Article;
import trade.ArticleTypes;
import world.World;

public class ArticlePlaceTurret extends Article {
    private final World world;
    private GameScreen gameScreen;
    public ArticlePlaceTurret(World world, GameScreen gameScreen) {
        super(ArticleTypes.PLACE_TURRET, 50);
        this.gameScreen = gameScreen;
        this.world = world;
    }

    @Override
    protected void giveArticleContent(Player buyer) {
        world.getSpritesOnWorld().add(new Turret(buyer.getPosX(), buyer.getPosY(), new DefaultCollisionManager()));
        price = price + 400;
    }

    @Override
    protected boolean maximumReach(Player buyer) {
        return false;
    }
}
