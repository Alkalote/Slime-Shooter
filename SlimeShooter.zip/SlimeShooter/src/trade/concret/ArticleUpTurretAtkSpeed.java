package trade.concret;

import sprite.player.Player;
import sprite.turret.TurretTimer;
import trade.Article;
import trade.ArticleTypes;

public class ArticleUpTurretAtkSpeed extends Article {
    private TurretTimer tourelleTimer;
    public ArticleUpTurretAtkSpeed(TurretTimer tourelleTimer) {
        super(ArticleTypes.UP_TURRET_ATK_SPEED, 1000);
        this.tourelleTimer = tourelleTimer;
    }

    @Override
    protected void giveArticleContent(Player buyer) {
        tourelleTimer.setTurretAtkSpeed(tourelleTimer.getTurretAtkSpeed() + 1);
        price = price + 1500;
    }

    @Override
    protected boolean maximumReach(Player buyer) {
        return false;
    }
}
