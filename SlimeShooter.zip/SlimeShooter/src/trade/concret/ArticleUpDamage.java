package trade.concret;

import sprite.player.Player;
import trade.Article;
import trade.ArticleTypes;

public class ArticleUpDamage extends Article {
    public ArticleUpDamage() {
        super(ArticleTypes.UP_DAMAGE, 100);
    }

    @Override
    protected void giveArticleContent(Player buyer) {
        buyer.setAtk(buyer.getAtk() + 1);
        price = price + 50;
    }

    @Override
    protected boolean maximumReach(Player buyer) {
        return false;
    }
}
