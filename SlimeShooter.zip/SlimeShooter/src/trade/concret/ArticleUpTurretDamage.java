package trade.concret;

import sprite.player.Player;
import sprite.turret.Turret;
import trade.Article;
import trade.ArticleTypes;
import world.World;

public class ArticleUpTurretDamage extends Article {
    private World world;
    public ArticleUpTurretDamage(World world) {
        super(ArticleTypes.UP_TURRET_DAMAGE, 1250);
        this.world = world;
    }

    @Override
    protected void giveArticleContent(Player buyer) {
        Turret.setBaseDamage(Turret.getBaseDamage() + 1);
        for(int i = 0; i < world.getSpritesOnWorld().size(); i++){
            if (world.getSpritesOnWorld().get(i) instanceof Turret){
                world.getSpritesOnWorld().get(i).setAtk(Turret.getBaseDamage());
            }
        }
        price = price + 1000;
    }

    @Override
    protected boolean maximumReach(Player buyer) {
        return false;
    }
}
