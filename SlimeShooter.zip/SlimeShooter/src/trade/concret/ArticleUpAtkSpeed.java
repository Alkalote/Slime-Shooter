package trade.concret;

import sprite.player.Player;
import trade.Article;
import trade.ArticleTypes;

public class ArticleUpAtkSpeed extends Article {

    public ArticleUpAtkSpeed() {
        super(ArticleTypes.UP_ATTACK_SPEED, 40);
    }

    @Override
    protected void giveArticleContent(Player buyer) {
        buyer.setAtkSpeed(buyer.getAtkSpeed() + 1);
        price = (int) Math.ceil(price*1.5);
    }

    @Override
    protected boolean maximumReach(Player buyer) {
        return buyer.getAtkSpeed() >= buyer.getAtkSpeedMax();
    }
}
