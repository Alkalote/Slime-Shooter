package trade;

import javafx.application.Platform;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;
import sprite.player.Player;

/**
 * Article est une classe représentant quelquechose pouvant être acheté dans le jeu,
 * pour ajouter un nouvel article, vous devez:
 *  - Ajouter un nouvel article dans l'Enum ArticleTypes
 *  - Créer un Article concret dans le quel vous définirez son prix, son id (au constructeur avec super)
 *    et son contenu.
 *    Je conseille de créer ce nouvel article dans le package: trade.concrete
 *  - Ne pas oublier de l'associer a un bouton dans la Map du constructeur de TraderSetup
 * @see ArticleTypes
 * @see TraderSetup
 * @see trade.concret.ArticlePlaceTurret
 * @see trade.concret.ArticleUpDamage
 * @see trade.concret.ArticleUpTurretAtkSpeed
 * @see trade.concret.ArticleUpTurretDamage
 */
public abstract class Article {
    private final ArticleTypes id;

    protected int price;

    private StringProperty buttonText = new SimpleStringProperty();
    public StringProperty getButtonTextProperty(){ return buttonText; }
    public String getButtonText(){ return buttonText.get(); }
    public void setButtonText(String newText){
        Platform.runLater( () -> buttonText.set(newText));
    }

    private StringProperty canBuyStyle = new SimpleStringProperty();
    public StringProperty getCanBuyStyleProperty(){ return canBuyStyle; }
    public String getCanBuyStyle(){ return canBuyStyle.get(); }
    public void setCanBuyStyle(String newStyle){
        Platform.runLater( () -> canBuyStyle.set(newStyle));
    }

    public Article(ArticleTypes id, int price){
        this.id = id;
        this.price = price;
        setCanBuyStyle("-fx-background-color: #FF0000;");
    }

    /**
     * Fait payer le joueur puis lui donne ce qu'il a acheté
     * @param player
     * [NE PAS REDEFINIR SINON COMPORTEMENT INDETERMINE]
     */
    public void buyTheArticle(Player player){
        if (!maximumReach(player)){
            if (pay(player)){
                giveArticleContent(player);
            }
        }
    }

    /**
     * Fait payer le prix de l'article au joueur donné en paramètre
     * @param player
     * @return
     */
    private boolean pay(Player player){
        if (player.getMoney() >= price){
            player.setMoney(player.getMoney() - price);
            return true;
        }
        return false;
    }

    /**
     * Cette méthode donne l'article acheté au joueur, cela peut être une amélioration
     * de sa vitesse d'attaque ou bien de ses dégats par exemple.
     * A vous de la définir.
     * Vous pouvez choisir d'augmenter le prix a chaque upgrade
     * @param buyer
     */
    protected abstract void giveArticleContent(Player buyer);

    /**
     * Dit si on a atteint le maximum de l'amélioration
     * @param buyer
     * @return True : le maximum est atteint
     *         False : le maximum n'est pas encore atteint
     */
    protected abstract boolean maximumReach(Player buyer);

    /**
     * Change la couleur du bouton en fonction de la money du joueur
     * @param player
     */
    public void updateButton(Player player){
        if (maximumReach(player)) {
            setCanBuyStyle("-fx-background-color: #99FF99;");
            setButtonText("MAX");
        }
        else if(player.getMoney() >= price) {
            setCanBuyStyle("-fx-background-color: #00FF00;");
            setButtonText(String.valueOf(price));
        }
        else {
            setCanBuyStyle("-fx-background-color: #FF0000;");
            setButtonText(String.valueOf(price));
        }
    }

    public ArticleTypes getId() {
        return id;
    }
}
