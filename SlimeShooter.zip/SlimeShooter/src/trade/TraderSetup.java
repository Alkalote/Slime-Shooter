package trade;

import javafx.scene.control.Button;
import sprite.player.Player;

import java.util.Iterator;
import java.util.Map;

/**
 * Cette classe a pour unique but de délester le GameController d'une
 * responsabilité : Gérer le système d'achat d'articles.
 */
public class TraderSetup {
    private Buyer buyer;
    public TraderSetup(Player player, Map<Article, Button> trades){
        buyer = new Buyer(player);
        setupCatalog(trades.keySet().iterator());
        bindArticlesAndButtons(trades);
    }

    /**
     * Référence tout les articles possibles a acheter dans le catalogue de l'instance de Buyer
     * que possède TraderSetup
     * @see Buyer
     * @param articleIterator
     */
    private void setupCatalog(Iterator<Article> articleIterator){
        articleIterator.forEachRemaining(article -> buyer.addArticleToCatalog(article));
    }

    /**
     * Bind unidirectionnelement les articles du modèle aux boutons de la partie graphique FXML
     * @param trades
     */
    private void bindArticlesAndButtons(Map<Article, Button> trades){
        trades.keySet().iterator().forEachRemaining(article -> {
            trades.get(article).styleProperty().bind(article.getCanBuyStyleProperty());
            trades.get(article).textProperty().bind(article.getButtonTextProperty());
        });
    }

    /**
     * achète l'article demandé
     * @param article
     */
    public void buyArticle(ArticleTypes article){
        try {
            buyer.buyArticle(article);
        }
        catch (IllegalArgumentException e){
            System.out.println(e.getMessage());
        }
    }

    /**
     * Update le style de tout les articles
     */
    public void updateStyleOfAllArticles(){
        buyer.updateStyleOfAllArticles();
    }
}
