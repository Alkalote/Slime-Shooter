package trade;

import time.Observateur;

/**
 * Update les boutons d'achat en fonction de la money du joueur
 */
public class BuyButtonTimer implements Observateur {
    private final TraderSetup traderSetup;
    public BuyButtonTimer(TraderSetup traderSetup){
        this.traderSetup = traderSetup;
    }

    @Override
    public void notification() {
        traderSetup.updateStyleOfAllArticles();
    }

    @Override
    public void end() {

    }
}
