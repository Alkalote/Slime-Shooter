package trade;

/**
 * Dit tout les articles existants, pour en ajouter, voir la documentation de Article
 * @see Article
 */
public enum ArticleTypes {
    UP_ATTACK_SPEED,
    UP_NUMBER_OF_BULLETS,
    UP_DAMAGE,
    PLACE_TURRET,
    UP_TURRET_ATK_SPEED,
    UP_TURRET_DAMAGE
}
