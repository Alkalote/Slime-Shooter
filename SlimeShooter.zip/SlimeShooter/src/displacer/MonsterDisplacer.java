package displacer;

import collisions.HitBox;
import sprite.MovingSprite;
import sprite.monster.MonsterSprite;
import utils.GameScreen;
import utils.SimpleVector;

/**
 * Déplaceur de tout les Monstres du jeu
 */
public class MonsterDisplacer extends Displacer{
    public MonsterDisplacer(GameScreen gameScreen) {
        super(gameScreen);
    }

    @Override
    public void move(MovingSprite cible, SimpleVector movement) {
        if (!(cible instanceof MonsterSprite)) return;
        cible.setPosX((int) (cible.getPosX() + Math.ceil(movement.getNormUnitX()*cible.getSpeed())));
        cible.setPosY((int) (cible.getPosY() + Math.ceil(movement.getNormUnitY()*cible.getSpeed())));
    }

    @Override
    public boolean canMove(MovingSprite cible, SimpleVector movement) {
        if (!(cible instanceof MonsterSprite)) return false;
        HitBox testHitBox = new HitBox(cible.getPosX(), cible.getPosY(), cible.getHitBox().getTailleHitBoxX(),
                cible.getHitBox().getTailleHitBoxY());
        testHitBox.setCoinHautGaucheX(testHitBox.getCoinHautGaucheX()
                + (int) Math.ceil(movement.getNormUnitX()*cible.getSpeed()));
        testHitBox.setCoinHautGaucheY(testHitBox.getCoinHautGaucheY()
                + (int) Math.ceil(movement.getNormUnitY()*cible.getSpeed()));
        return !gameScreen.outOfScreen(testHitBox.getCoinHautGaucheX(), testHitBox.getCoinHautGaucheY())
                && !gameScreen.outOfScreen(testHitBox.getCoinHautGaucheX(), testHitBox.getCoinBasDroiteY())
                && !gameScreen.outOfScreen(testHitBox.getCoinBasDroiteX(), testHitBox.getCoinHautGaucheY())
                && !gameScreen.outOfScreen(testHitBox.getCoinBasDroiteX(), testHitBox.getCoinBasDroiteY());
    }
}
