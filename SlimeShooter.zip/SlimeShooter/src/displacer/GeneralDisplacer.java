package displacer;

import sprite.MovingSprite;
import sprite.Sprite;

/**
 * Classe utilitaire, fait les tests nécessaires et déplace le sprite donné
 */
public class GeneralDisplacer {
    /**
     * Déplace le sprite donné en paramètre
     * @param actualSprite
     */
    public static void moveThisSprite(Sprite actualSprite){
        if (actualSprite instanceof MovingSprite){
            if (((MovingSprite) actualSprite).canMove()) ((MovingSprite) actualSprite).move();
            else ((MovingSprite) actualSprite).goToMiddleOfScreen();
        }
    }
}
