package displacer;

import sprite.MovingSprite;
import utils.GameScreen;
import utils.SimpleVector;

/**
 * Permet de personnaliser l'algorithme de déplacement des sprites
 * @see MovingSprite
 */
public abstract class Displacer {
    protected final GameScreen gameScreen;
    protected Displacer(GameScreen gameScreen){
        this.gameScreen = gameScreen;
    }

    /**
     * Fait l'algorithme de déplacement d'un sprite cible en fonction du vecteur donné
     * @param cible
     * @param movement
     */
    public abstract void move(MovingSprite cible, SimpleVector movement);

    /**
     * Dit si l'algorithme de déplacement peut être fait ou non
     * @param cible
     * @param movement
     */
    public abstract boolean canMove(MovingSprite cible, SimpleVector movement);

    /**
     * Fait aller le sprite au milieu de l'écran, sert beaucoup pour les empêcher de quiter l'écran
     * @param cible
     */
    public void goToMiddleOfScreen(MovingSprite cible) {
        SimpleVector deplacement = new SimpleVector(cible.getPosX(), cible.getPosY(), gameScreen.getxMax()/2,
                gameScreen.getyMax()/2);
        cible.setPosX((int) (cible.getPosX() + Math.ceil(deplacement.getNormUnitX()*cible.getSpeed())));
        cible.setPosY((int) (cible.getPosY() + Math.ceil(deplacement.getNormUnitY()*cible.getSpeed())));
    }
}
