package waves;

import sprite.monster.MobType;
import sprite.monster.concret.BasicMonsterSprite;
import sprite.monster.concret.MiniBossMonsterSprite;
import sprite.monster.concret.StrongMonsterSprite;

/**
 * Fait évoluer une vague
 */
public class WaveEvolver {
    /**
     * Fait évoluer le contenu d'une vague
     * @param waveData
     * @param timeBetweenWaves
     * @return
     */
    public int evoluteWave(WaveData waveData, int timeBetweenWaves){
        waveData.setWaveNumber(waveData.getWaveNumber() + 1);
        if (waveData.getWaveNumber() % 5 == 0) waveData.addContent(MobType.STRONG_MONSTER_SPRITE);
        waveData.addContent(MobType.BASIC_MONSTER_SPRITE);
        waveData.addContent(MobType.BASIC_MONSTER_SPRITE);

        if (waveData.getWaveContentClass().size() >= 30){
            BasicMonsterSprite.evoluteMobType();
            StrongMonsterSprite.evoluteMobType();
            MiniBossMonsterSprite.evoluteMobType();

            waveData.getWaveContentClass().clear();
            waveData.addContent(MobType.MINI_BOSS_MONSTER_SPRITE);
            waveData.addContent(MobType.BASIC_MONSTER_SPRITE);
            waveData.addContent(MobType.BASIC_MONSTER_SPRITE);
            waveData.addContent(MobType.STRONG_MONSTER_SPRITE);
            waveData.addContent(MobType.STRONG_MONSTER_SPRITE);
        }
        else waveData.removeContent(MobType.MINI_BOSS_MONSTER_SPRITE);

        if (waveData.getWaveNumber()%2 == 0) return timeBetweenWaves + 1;
        return timeBetweenWaves;
    }
}
