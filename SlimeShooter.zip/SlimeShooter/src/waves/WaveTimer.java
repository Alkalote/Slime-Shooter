package waves;

import javafx.application.Platform;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;
import sprite.Sprite;
import time.Observateur;
import utils.GameScreen;
import time.Timer;
import world.World;

/**
 * Fait apparaitre des vagues tout les certains laps de temps
 */
public class WaveTimer implements Observateur {
    private int ticks; //sec
    private int sec;
    private final int ticksPerSecond;
    private int timeBetweenWaves;
    private final World world;
    private WaveData waveData;
    private final WaveSpawner waveSpawner;
    private final WaveEvolver waveEvolver;
    private final Sprite objectiveMobs;


    private StringProperty timeNextWave = new SimpleStringProperty();
    public StringProperty getTimeNextWaveProperty(){ return timeNextWave; }
    public String getimeNextWave(){ return timeNextWave.get(); }
    public void setimeNextWave(String newTimeNextWave){
        Platform.runLater(() -> timeNextWave.set(newTimeNextWave));
    }

    public WaveTimer(World world, GameScreen gameScreen, Sprite objectiveMobs, Timer timer){
        ticks=0;
        sec = 0;
        timeBetweenWaves = 10;
        this.world = world;
        this.objectiveMobs = objectiveMobs;
        this.ticksPerSecond = timer.getTicksPerSecond();
        waveData = new WaveData();
        waveSpawner = new WaveSpawner(gameScreen);
        waveEvolver = new WaveEvolver();
        timeBetweenWaves = 10;
    }

    /**
     * Fait apparaitre / évoluer une vague toutes le certains laps de temps
     */
    public void notification() {
        ticks ++;
        if (ticks%ticksPerSecond == 0){
            sec++;
            setimeNextWave((timeBetweenWaves - (sec % timeBetweenWaves)) + "s");
            if (sec == timeBetweenWaves){
                timeBetweenWaves = waveEvolver.evoluteWave(waveData, timeBetweenWaves);
                waveSpawner.spawnWave(waveData, world, objectiveMobs);
                sec = 0;
            }
        }
    }

    @Override
    public void end() {
        waveData = new WaveData();
        ticks=0;
        sec = 0;
    }

    public WaveData getWaveData() {
        return waveData;
    }
}
