package waves;

import javafx.application.Platform;
import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleIntegerProperty;
import sprite.monster.MobType;

import java.util.ArrayList;
import java.util.List;

/**
 * Définit le contenu d'une vague
 */
public class WaveData {
    private IntegerProperty waveNumber = new SimpleIntegerProperty();
    public IntegerProperty getWaveNumberProperty(){ return waveNumber; }
    public int getWaveNumber(){ return waveNumber.get(); }
    public void setWaveNumber(int newWaveNumber){
        Platform.runLater( () -> waveNumber.set(newWaveNumber));
    }

    private List<MobType> waveContentClass;
    public WaveData() {
        waveContentClass = new ArrayList<>();
        setWaveNumber(1);
    }

    public void addContent(MobType mobType){
        waveContentClass.add(mobType);
    }

    public void removeContent(MobType mobType){
        waveContentClass.remove(mobType);
    }

    public List<MobType> getWaveContentClass(){ //pas très propre demander conseil
        return waveContentClass;
    }

}
