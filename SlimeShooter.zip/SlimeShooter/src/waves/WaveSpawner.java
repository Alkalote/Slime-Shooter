package waves;

import sprite.Sprite;
import sprite.monster.manipulation.MobManager;
import sprite.monster.MobType;
import utils.GameScreen;
import utils.TextTransformations;
import world.World;

/**
 * Fait apparaître une vague
 */
public class WaveSpawner {
    private MobManager mobManager;
    public WaveSpawner(GameScreen gameScreen) {
        mobManager = new MobManager(gameScreen);
    }

    /**
     * Fait apparaitre une vague
     * @param waveData
     * @param world
     * @param objective
     */
    public void spawnWave(WaveData waveData, World world, Sprite objective) {
        waveData.getWaveContentClass().forEach(mob -> {
            mobManager.spawnMob(conversion(mob), world, objective);
        });
    }

    /**
     * Convertit un MobType en string qui va servir a l'introspection
     * @param mobType
     * @return
     */
    private String conversion(MobType mobType) {
        String packet = "sprite.monster.concret.";
        String conversion = String.valueOf(mobType);
        conversion = conversion.toLowerCase();
        conversion = conversion.replace("_", " ");
        conversion = TextTransformations.toTitleCase(conversion);
        conversion = conversion.replace(" ", "");
        conversion = packet.concat(conversion);
        return conversion;
    }
}
