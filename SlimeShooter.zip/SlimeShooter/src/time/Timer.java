package time;

import javafx.application.Platform;
import time.Observateur;

import java.util.ArrayList;
import java.util.ConcurrentModificationException;
import java.util.List;

/**
 * Thread qui notifie ses observateurs tout les certain temps
 */
public class Timer extends Thread{
    private boolean run;
    private int threadNumber;
    private List<Observateur> observers;
    private Runner runner;
    private int ticksPerSecond;

    /**
     * Constructeur du timer
     * @param threadNumber Numéro du thread
     * @param runner Instance qui lui donne l'ordre de tourner ou de s'aretter
     * @param ticksPerSecond Le nombre de notifications envoyées par secondes
     */
    public Timer(int threadNumber, Runner runner, int ticksPerSecond){
        this.threadNumber = threadNumber;
        run = true;
        observers = new ArrayList<>();
        this.runner = runner;
        this.ticksPerSecond = ticksPerSecond;
    }

    /**
     * Envoie des notifications tout les "ticksPerSecond" a tout les Observateurs du timer
     */
    @Override
    public void run() {
        int ticks = 0;
        while (runner.running()){
            notifyObservers();
            ticks++;
            try {
                Thread.sleep(1000/ticksPerSecond);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
        notifyEndObservers();
    }

    /**
     * Notifie tout les observateurs abonnés
     */
    private void notifyObservers(){
        try {
            observers.forEach(Observateur::notification);
        }
        catch (ConcurrentModificationException e){
            e.printStackTrace();
        }
    }

    /**
     * Notifie tout les observateurs abonnés de la fin du timer
     */
    private void notifyEndObservers(){
        observers.forEach(Observateur::end);
    }

    /**
     * Abonne un observateur
     * @param observer
     */
    public void addObserver(Observateur observer){
        if (observer == null) return;
        Platform.runLater(() -> observers.add(observer));
    }

    /**
     * Donne le nombre de notifications envoyées par secondes de ce timer
     * @return
     */
    public int getTicksPerSecond() {
        return ticksPerSecond;
    }
}
