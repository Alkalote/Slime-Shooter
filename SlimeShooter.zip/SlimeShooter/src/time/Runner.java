package time;

/**
 * Sert a arreter le thread proprement
 */
public class Runner {
    private boolean run;
    public Runner(boolean run){
        this.run = run;
    }

    /**
     * Dit si le thread doit continuer de tourner ou non
     * @return
     */
    public boolean running(){
        return run;
    }

    public void setRun(boolean run) {
        this.run = run;
    }
}
