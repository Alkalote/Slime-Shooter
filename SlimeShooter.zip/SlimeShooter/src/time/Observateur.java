package time;

/**
 * Les classes qui implémentent cette interface et qui s'abonnent au timer recevront des ticks toutes les secondes
 * @see Timer
 */
public interface Observateur {
    /**
     * Méthode appelée tout les ticks
     */
    public void notification();

    /**
     * Méthode appelée a la fin du thread
     */
    public void end();
}
