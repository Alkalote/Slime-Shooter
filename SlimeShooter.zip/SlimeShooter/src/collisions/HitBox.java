package collisions;

/**
 * Représente la HitBox de tout les sprites du jeu
 * @see sprite.Sprite
 */
public class HitBox {
    private int coinHautGaucheX;
    private int coinHautGaucheY;
    private int coinBasDroiteX;
    private int coinBasDroiteY;
    private final int tailleHitBoxX;
    private final int tailleHitBoxY;

    /**
     * Calcule et sauvegarde les coordonnées de deux points formant le carré/rectangle de la HitBox
     * @param coinGaucheX
     * @param coinGaucheY
     * @param tailleHitBoxX
     * @param tailleHitBoxY
     */
    public HitBox(int coinGaucheX, int coinGaucheY, int tailleHitBoxX, int tailleHitBoxY){
        this.coinHautGaucheX = coinGaucheX;
        this.coinHautGaucheY = coinGaucheY;
        this.tailleHitBoxX = tailleHitBoxX;
        this.tailleHitBoxY = tailleHitBoxY;

        coinBasDroiteX = coinGaucheX + tailleHitBoxX;
        coinBasDroiteY = coinGaucheY + tailleHitBoxY;
        //System.out.println(coinHautGaucheX + " " + coinHautGaucheY + " " + coinBasDroiteX + " " + coinBasDroiteY);
    }

    /**
     * Donne les coordonnées X du centre de la HitBox
     * @return
     */
    public int getCenterX(){
        //System.out.println((coinHautGaucheX + tailleHitBoxX/2));
        return coinHautGaucheX + tailleHitBoxX/2;
    }

    /**
     * Donne les coordonnées Y du centre de la HitBox
     * @return
     */
    public int getCenterY(){
        //System.out.println((coinHautGaucheX + tailleHitBoxX/2));
        return coinHautGaucheY + tailleHitBoxY/2;
    }

    /**
     * Met aussi a jour coinBasDroiteX
     * @param coinHautGaucheX
     */
    public void setCoinHautGaucheX(int coinHautGaucheX) {
        this.coinHautGaucheX = coinHautGaucheX;
        coinBasDroiteX = coinHautGaucheX + tailleHitBoxX;
    }

    /**
     * Met aussi a jour coinBasGaucheX
     * @param coinHautGaucheY
     */
    public void setCoinHautGaucheY(int coinHautGaucheY) {
        this.coinHautGaucheY = coinHautGaucheY;
        coinBasDroiteY = coinHautGaucheY + tailleHitBoxY;
    }

    public int getTailleHitBoxX() {
        return tailleHitBoxX;
    }

    public int getTailleHitBoxY() {
        return tailleHitBoxY;
    }

    public int getCoinHautGaucheX() {
        return coinHautGaucheX;
    }

    public int getCoinHautGaucheY() {
        return coinHautGaucheY;
    }

    public int getCoinBasDroiteX() {
        return coinBasDroiteX;
    }

    public int getCoinBasDroiteY() {
        return coinBasDroiteY;
    }
}
