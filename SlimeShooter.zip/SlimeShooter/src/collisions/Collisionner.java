package collisions;

import sprite.Sprite;
import utils.Distance;

/**
 * Classe utilitaire, elle sert a déterminer si il y a collision entre 2 sprites
 */
public class Collisionner {
    /**
     * Détermine si deux objets sont en collision.
     * @param o1
     * @param o2
     * @return
     */
    public static boolean isCollide(Sprite o1, Sprite o2){
        int distance = Distance.getDistance(o1, o2);
        return distance <= o1.getHitBox().getTailleHitBoxX()
                || distance <= o1.getHitBox().getTailleHitBoxY()
                || distance <= o2.getHitBox().getTailleHitBoxX()
                || distance <= o2.getHitBox().getTailleHitBoxY();
    }
}
