package collisions;

import sprite.Sprite;
import world.World;

/**
 * Check toutes les collisions possibles
 */
public class GeneralCollisionner {
    private World world;
    public GeneralCollisionner(World world){
        this.world = world;
    }
    public void doCollisionsWithOthers(Sprite me){
        Sprite other;
        for (int i=0; i < world.getSpritesOnWorld().size(); i++){
            other = world.getSpritesOnWorld().get(i);
            if (me == other) continue;
            if (Collisionner.isCollide(me, other)){
                me.getCollisionManager().doCollisions(me, other);
            }
        }
    }
}
