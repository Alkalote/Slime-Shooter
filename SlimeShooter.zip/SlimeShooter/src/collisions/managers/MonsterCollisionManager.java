package collisions.managers;

import sprite.MovingSprite;
import sprite.Sprite;
import sprite.monster.MonsterSprite;

/**
 * Gestion des collisions des Monstres
 */
public class MonsterCollisionManager implements CollisionManager{
    @Override
    public void doCollisions(Sprite me, Sprite other) {
        if (!(me instanceof MonsterSprite) || !(other instanceof MonsterSprite)) return;
        ((MovingSprite) other).moveReverse(me.getCenterX(), me.getCenterY());
    }
}
