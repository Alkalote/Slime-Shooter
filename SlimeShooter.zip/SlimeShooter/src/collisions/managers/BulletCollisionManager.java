package collisions.managers;

import sprite.Sprite;
import sprite.monster.MonsterSprite;
import sprite.bullets.Bullet;

/**
 * Gestion des collisions des balles
 */
public class BulletCollisionManager implements CollisionManager{
    /**
     * Gère les collisions entre un projectile et un monstre, un monstre prends des dégats lors de la
     * collision et la collision disparait
     * @param me
     * @param other
     * @see CollisionManager
     * @see Bullet
     * @see MonsterSprite
     */
    @Override
    public void doCollisions(Sprite me, Sprite other) {
        if(!(me instanceof Bullet) || !(other instanceof MonsterSprite)) return;
        Bullet bullet = (Bullet) me;
        MonsterSprite monster = (MonsterSprite) other;
        other.setPv(monster.getPv() - bullet.getAtk());
        bullet.setPv(0);
    }
}
