package collisions.managers;

import collisions.Collisionner;
import sprite.Sprite;
import sprite.MovingSprite;
import sprite.monster.MonsterSprite;

/**
 * Gestion des collisions par défaut
 */
public class DefaultCollisionManager implements CollisionManager{
    /**
     * Méthode de gestion des collisions entre deux sprites par défaut.
     * @param me
     * @param other
     */
    @Override
    public void doCollisions(Sprite me, Sprite other) {
        if (!(other instanceof MovingSprite)) return;
        ((MovingSprite) other).moveReverse(me.getCenterX(), me.getCenterY());
    }
}
