package collisions.managers;

import sprite.Sprite;

public interface CollisionManager {
    public void doCollisions(Sprite me, Sprite other);
}
