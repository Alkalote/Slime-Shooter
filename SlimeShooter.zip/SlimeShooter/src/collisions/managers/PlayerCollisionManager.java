package collisions.managers;

import sprite.MovingSprite;
import sprite.Sprite;
import sprite.monster.MonsterSprite;
import sprite.player.Player;
import sprite.player.PlayerManager;

/**
 * Gestion des collisions des Joueurs
 */
public class PlayerCollisionManager implements CollisionManager{
    private PlayerManager playerManager;
    public PlayerCollisionManager(PlayerManager playerManager){
        this.playerManager = playerManager;
    }
    @Override
    public void doCollisions(Sprite me, Sprite other) {
        if (!(me instanceof Player)) return;
        if (other instanceof MovingSprite){
            if (other instanceof MonsterSprite){
                if (((MonsterSprite) other).canAttack()){
                    playerManager.takeDamage((Player) me, other.getAtk());
                    ((MonsterSprite)other).startCooldown();
                }
            }
            ((MovingSprite) other).moveReverse(me.getCenterX(), me.getCenterY());
        }
    }
}
