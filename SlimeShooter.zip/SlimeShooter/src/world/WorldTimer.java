package world;

import javafx.application.Platform;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;
import sprite.Sprite;
import sprite.monster.MonsterSprite;
import sprite.player.Player;
import sprite.player.PlayerManager;
import time.Observateur;
import time.Runner;
import utils.GameScreen;

public class WorldTimer implements Observateur {
    private final World world;
    private final Player player;
    private final PlayerManager playerManager;
    private final Runner runner;
    private int ticks=0;
    private int ticksPerSecond;

    private StringProperty timeAlive = new SimpleStringProperty();
    public StringProperty getTimeAliveProperty(){ return timeAlive; }
    public String getTimeAlive(){ return timeAlive.get(); }
    public void setTimeAlive(String newTimeAlive){
        Platform.runLater(() -> timeAlive.set(newTimeAlive));
    }

    public WorldTimer(World world, Player player, GameScreen gameScreen, Runner runner, int ticksPerSecond){
        this.world = world;
        this.player = player;
        this.runner = runner;
        playerManager = new PlayerManager(world, gameScreen);
        this.ticksPerSecond = ticksPerSecond;
    }

    /**
     * Applique toutes les règles appliquées au monde (ex : plus de pv = mort)
     */
    @Override
    public void notification() {
        ticks++;
        int s = (ticks/ticksPerSecond)%60;
        int min = ((ticks/ticksPerSecond)/60)%60;
        int h = (((ticks/ticksPerSecond)/60)/60)%24;
        setTimeAlive(h + "h : " + min + "min : " + s + "s");
        if (player.isDead()){
            runner.setRun(false);
        }
        for (int i=0; i < world.getSpritesOnWorld().size(); i++){
            Sprite sprite = world.getSpritesOnWorld().get(i);
            if (sprite instanceof Player) continue;
            if (sprite instanceof MonsterSprite){
                ((MonsterSprite) sprite).reduceCooldown();
            }
            if (sprite.isDead()){
                if (sprite instanceof MonsterSprite){
                    playerManager.upScore(player, (MonsterSprite) sprite);
                    playerManager.gainMoney(player, (MonsterSprite) sprite);
                }
                world.getSpritesOnWorld().remove(i);
            }
        }
    }

    @Override
    public void end() {
    }
}
