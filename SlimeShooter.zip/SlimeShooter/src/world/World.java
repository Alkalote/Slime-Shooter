package world;

import sprite.Sprite;

import java.util.ArrayList;
import java.util.List;

/**
 * Définit tout les Sprites présents dans le monde
 * @see World
 */
public class World {
    private List<Sprite> spritesOnWorld;

    public World(){
        spritesOnWorld = new ArrayList<>();
    }

    public List<Sprite> getSpritesOnWorld() {
        return spritesOnWorld;
    }
}
